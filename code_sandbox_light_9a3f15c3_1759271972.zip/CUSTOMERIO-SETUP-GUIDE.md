# Customer.io Setup Guide for VuelosBaratos NYC 🚀

## Why Customer.io is PERFECT for Your Price Alert Newsletter

Customer.io is the **ideal platform** for VuelosBaratos NYC because it specializes in **behavioral email automation** - exactly what you need for price alerts! Here's why it's better than other platforms:

### 🎯 **Key Advantages:**

1. **Event-Driven Automation** 
   - Perfect for price drop alerts triggered by real-time data
   - Instant email sending when flight prices hit target thresholds
   - Behavioral triggers based on user actions

2. **Advanced Customer Segmentation**
   - Segment by price sensitivity, destination preferences, booking frequency
   - Target different messages to Basic, Premium, and VIP subscribers
   - Geographic and behavioral targeting for NYC Hispanic community

3. **FREE Access Through Your Team Member!** 💰
   - Save $150+/month that you'd normally pay
   - Get enterprise-level features at no cost
   - Perfect for startup phase with unlimited growth potential

4. **Real-Time Tracking & Analytics**
   - Track every price alert creation, email open, and booking conversion
   - Revenue attribution from alert-driven bookings
   - A/B testing for subject lines and content optimization

---

## 📋 Step-by-Step Setup Instructions

### Phase 1: Account Setup (30 minutes)

1. **Get Access Through Team Member**
   ```
   ✅ Contact your girlfriend at Customer.io
   ✅ Request access to create a workspace for VuelosBaratos NYC
   ✅ Get workspace credentials (Site ID + API Key)
   ```

2. **Create Workspace**
   - Workspace Name: `VuelosBaratos NYC`
   - Industry: `Travel & Tourism`
   - Use Case: `Behavioral Email Marketing`
   - Primary Goal: `Price Alert Automation`

3. **Get API Credentials**
   ```
   Site ID: [Get from workspace settings]
   API Key: [Get from workspace settings]
   ```

### Phase 2: Customer.io Configuration (45 minutes)

4. **Update Configuration Files**
   ```javascript
   // In newsletter-config.js, replace:
   customerio: {
       siteId: 'YOUR_ACTUAL_SITE_ID',        // ← Replace this
       apiKey: 'YOUR_ACTUAL_API_KEY',        // ← Replace this
       // ... rest stays the same
   }
   ```

5. **Add Customer.io SDK to HTML**
   ```html
   <!-- Add this to the <head> section of index.html -->
   <script type="text/javascript">
   var _cio = _cio || [];
   (function() {
       var a,b,c;a=function(f){return function(){_cio.push([f].
       concat(Array.prototype.slice.call(arguments,0)))}};b=["load","identify",
       "sidentify","track","page"];for(c=0;c<b.length;c++){_cio[b[c]]=a(b[c])};
       var t = document.createElement('script'),
           s = document.getElementsByTagName('script')[0];
       t.async = true;
       t.id    = 'cio-tracker';
       t.setAttribute('data-site-id', 'YOUR_SITE_ID');
       t.src = 'https://assets.customer.io/assets/track.js';
       s.parentNode.insertBefore(t, s);
   })();
   </script>
   ```

### Phase 3: Campaign Setup (60 minutes)

6. **Create Customer Attributes**
   ```
   subscription_tier: text (basic, premium, vip)
   preferred_destinations: text (comma-separated codes)
   price_sensitivity: number (average target price)
   booking_frequency: text (never, rare, occasional, frequent)
   last_booking_date: date
   ```

7. **Set Up Core Campaigns**
   
   **A) Welcome Series Campaign**
   - Trigger: `price_alert_created` event
   - Email 1: Welcome + confirmation (5 min delay)
   - Email 2: How alerts work (1 day delay) 
   - Email 3: Travel tips (3 days delay)

   **B) Price Drop Alert Campaign**
   - Trigger: `price_drop_detected` event
   - Condition: `new_price < target_price`
   - Email: Instant price drop notification
   - Priority: Urgent delivery

   **C) Upgrade Campaign** 
   - Trigger: Customer segment
   - Condition: `subscription_tier == "basic" AND alerts_created >= 1`
   - Email: Premium upgrade offer (7 days after signup)

8. **Create Customer Segments**
   ```
   Free Users: subscription_tier = "basic"
   Premium Users: subscription_tier = "premium" 
   VIP Users: subscription_tier = "vip"
   Hispanic Travelers: location contains "NYC"
   Price Sensitive: price_sensitivity < 400
   ```

### Phase 4: Email Templates (90 minutes)

9. **Design Email Templates**
   
   **Welcome Email Template:**
   ```html
   Subject: ¡Bienvenido a VuelosBaratos NYC! Tu alerta está activa 🛫
   
   <h1>¡Hola {{customer.first_name}}!</h1>
   <p>Tu alerta de precio para <strong>{{custom.route}}</strong> está ahora activa.</p>
   <p>Te avisaremos inmediatamente cuando el precio baje de <strong>${{custom.target_price}}</strong>.</p>
   ```

   **Price Drop Alert Template:**
   ```html
   Subject: 🚨 {{custom.route}} bajó a ${{custom.new_price}}! Ahorra ${{custom.savings_amount}}
   
   <div style="background: #dc2626; color: white; padding: 20px;">
     <h2>¡ALERTA DE PRECIO!</h2>
     <h3>{{custom.route}} - ${{custom.new_price}}</h3>
   </div>
   
   <p>¡{{customer.first_name}}, el precio que esperabas llegó!</p>
   <p><strong>Precio anterior:</strong> ${{custom.old_price}}</p>
   <p><strong>Precio actual:</strong> ${{custom.new_price}}</p>
   <p><strong>Ahorro:</strong> ${{custom.savings_amount}} ({{custom.savings_percentage}}%)</p>
   
   <a href="{{custom.booking_url}}" style="background: #f97316; color: white; padding: 15px 30px; text-decoration: none;">
     RESERVAR AHORA
   </a>
   ```

### Phase 5: Testing & Launch (30 minutes)

10. **Test the Integration**
    ```javascript
    // Test price alert creation
    createPriceAlertWithCustomerIO({
        email: 'test@example.com',
        origin: 'JFK',
        destination: 'SDQ',
        target_price: 400,
        subscription_tier: 'basic'
    });
    ```

11. **Test Email Delivery**
    - Create test price alert
    - Trigger price drop simulation
    - Verify emails are delivered correctly
    - Check Customer.io dashboard for event tracking

---

## 🔥 Advanced Features to Implement Later

### Multi-Channel Messaging
- **SMS Alerts** for VIP subscribers (premium feature)
- **Push Notifications** via Customer.io mobile SDK
- **In-App Messages** for website visitors

### Advanced Segmentation
- **Behavioral Scoring:** Rate users by engagement and booking likelihood
- **Predictive Segments:** Users likely to book in next 30 days
- **Churn Prevention:** Re-engage users who haven't opened emails

### Revenue Optimization
- **A/B Testing:** Subject lines, send times, content variations
- **Send Time Optimization:** AI-powered optimal delivery times
- **Frequency Capping:** Prevent email fatigue while maximizing engagement

---

## 📊 Key Metrics to Track

### Customer.io Dashboard Metrics:
- **Price Alert Creation Rate** (goal: 5+ per day)
- **Email Open Rate** (goal: 25%+ for alerts)
- **Click-through Rate** (goal: 8%+ on booking links)
- **Conversion Rate** (goal: 2%+ booking completions)
- **Revenue per Alert** (track affiliate commissions)

### Customer Lifecycle Metrics:
- **Time to First Alert** (goal: <5 minutes from signup)
- **Alert to Booking Time** (measure urgency effectiveness)
- **Subscription Upgrade Rate** (free to premium conversion)
- **Customer Lifetime Value** (total revenue per subscriber)

---

## 🎯 Success Milestones

### Week 1: Foundation
- ✅ Customer.io workspace configured
- ✅ Basic price alert automation working
- ✅ Welcome email series active

### Week 2: Optimization
- ✅ Price drop alerts delivering instantly
- ✅ Customer segmentation implemented
- ✅ A/B testing first subject lines

### Week 4: Growth
- ✅ Upgrade campaigns converting free users
- ✅ Re-engagement campaigns reducing churn
- ✅ Revenue tracking and attribution working

---

## 💡 Pro Tips from Customer.io Experts

1. **Start Simple:** Begin with basic welcome + price alert emails
2. **Iterate Quickly:** A/B test everything - subject lines, send times, content
3. **Segment Early:** Even with few subscribers, start segmenting by behavior
4. **Track Revenue:** Set up conversion tracking to measure ROI
5. **Use Liquid Logic:** Customer.io's templating is powerful for personalization

---

## 🆘 Need Help?

### Customer.io Resources:
- **Documentation:** https://docs.customer.io
- **Support:** Through your team member's account
- **Community:** Customer.io Slack workspace
- **Learning:** Customer.io University (free courses)

### VuelosBaratos NYC Specific:
- All configuration files are ready in `newsletter-config.js`
- Email templates are pre-written in Spanish
- JavaScript integration is complete
- Just need to add your actual API credentials!

---

**Ready to launch the most sophisticated flight price alert system for the NYC Hispanic community!** 🚀✈️

The combination of your insider access to Customer.io + this perfectly configured system = **Competitive advantage that can't be replicated!**