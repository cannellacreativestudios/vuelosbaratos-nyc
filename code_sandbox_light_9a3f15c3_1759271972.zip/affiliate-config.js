/**
 * VuelosBaratos NYC - Affiliate Configuration
 * Configure your affiliate program IDs and tracking parameters
 */

// ===================================
// AFFILIATE PROGRAM CONFIGURATION
// ===================================

const AFFILIATE_CONFIG = {
    // Expedia Group Affiliate Program
    expedia: {
        affiliateId: 'YOUR_EXPEDIA_AFFILIATE_ID', // Replace with your actual ID
        baseUrl: 'https://www.expedia.com',
        trackingParams: {
            semcid: 'YOUR_SEMCID',
            SEMDTL: 'a1',
            Pwa_LP: 'HOMEPAGE'
        }
    },
    
    // Hotels.com Affiliate Program  
    hotels: {
        affiliateId: 'YOUR_HOTELS_AFFILIATE_ID', // Replace with your actual ID
        baseUrl: 'https://www.hotels.com',
        trackingParams: {
            pos: 'HCOM_US',
            locale: 'en_US'
        }
    },
    
    // Kayak Affiliate Program (if approved)
    kayak: {
        affiliateId: 'YOUR_KAYAK_AFFILIATE_ID', // Replace when approved
        baseUrl: 'https://www.kayak.com',
        trackingParams: {
            a: 'kan_273858', // Example tracking parameter
            url: '/flights'
        }
    },
    
    // Booking.com Affiliate Program (if approved via AWIN)
    booking: {
        affiliateId: 'YOUR_BOOKING_AFFILIATE_ID', // Replace if approved
        baseUrl: 'https://www.booking.com',
        trackingParams: {
            aid: '000000', // Your affiliate ID
            label: 'vuelosbaratos-nyc'
        }
    }
};

// ===================================
// FLIGHT BOOKING URL BUILDERS
// ===================================

/**
 * Build Expedia flight search URL with affiliate tracking
 */
function buildExpediaFlightUrl(searchParams) {
    const baseUrl = AFFILIATE_CONFIG.expedia.baseUrl + '/Flights-Search';
    const params = new URLSearchParams({
        // Flight search parameters
        'flight-type': searchParams.return ? 'on' : 'off',
        'starDate': searchParams.departure,
        'endDate': searchParams.return || '',
        'cabinClass': 'Economy',
        'adults': searchParams.passengers || '1',
        
        // Origin and destination
        'leg1': `from:${searchParams.origin},to:${searchParams.destination},departure:${searchParams.departure}TANYT`,
        
        // Affiliate tracking
        '_xpid': AFFILIATE_CONFIG.expedia.affiliateId,
        'semcid': AFFILIATE_CONFIG.expedia.trackingParams.semcid,
        'SEMDTL': AFFILIATE_CONFIG.expedia.trackingParams.SEMDTL,
        'Pwa_LP': AFFILIATE_CONFIG.expedia.trackingParams.Pwa_LP,
        
        // Source tracking
        'source': 'vuelosbaratosnyc.com',
        'campaign': 'hispanic-flight-deals'
    });
    
    return `${baseUrl}?${params.toString()}`;
}

/**
 * Build Hotels.com search URL with affiliate tracking
 */
function buildHotelsUrl(destination, checkIn, checkOut, guests = 1) {
    const baseUrl = AFFILIATE_CONFIG.hotels.baseUrl + '/search.do';
    const params = new URLSearchParams({
        // Hotel search parameters
        'resolved-location': destination,
        'q-check-in': checkIn,
        'q-check-out': checkOut,
        'q-rooms': '1',
        'q-room-0-adults': guests.toString(),
        'q-room-0-children': '0',
        
        // Affiliate tracking
        'aid': AFFILIATE_CONFIG.hotels.affiliateId,
        'pos': AFFILIATE_CONFIG.hotels.trackingParams.pos,
        'locale': AFFILIATE_CONFIG.hotels.trackingParams.locale,
        
        // Source tracking
        'source': 'vuelosbaratosnyc',
        'campaign': 'hispanic-hotels'
    });
    
    return `${baseUrl}?${params.toString()}`;
}

/**
 * Build Kayak flight search URL (if affiliate program approved)
 */
function buildKayakFlightUrl(searchParams) {
    const baseUrl = AFFILIATE_CONFIG.kayak.baseUrl + '/flights';
    const params = new URLSearchParams({
        // Flight parameters
        'sort': 'price_a',
        'adf': searchParams.passengers || '1',
        'from': searchParams.origin,
        'to': searchParams.destination,
        'depart': searchParams.departure,
        'return': searchParams.return || '',
        
        // Affiliate tracking
        'a': AFFILIATE_CONFIG.kayak.affiliateId,
        'source': 'vuelosbaratosnyc'
    });
    
    return `${baseUrl}?${params.toString()}`;
}

// ===================================
// DESTINATION-SPECIFIC CONFIGURATIONS
// ===================================

const DESTINATION_CONFIG = {
    // Dominican Republic
    'SDQ': {
        name: 'Santo Domingo',
        country: 'República Dominicana',
        flag: '🇩🇴',
        hotelDestination: 'SANTO_DOMINGO_DOMINICAN_REPUBLIC',
        averagePrice: 287,
        currency: 'USD'
    },
    'PUJ': {
        name: 'Punta Cana',
        country: 'República Dominicana', 
        flag: '🇩🇴',
        hotelDestination: 'PUNTA_CANA_DOMINICAN_REPUBLIC',
        averagePrice: 312,
        currency: 'USD'
    },
    
    // Colombia
    'BOG': {
        name: 'Bogotá',
        country: 'Colombia',
        flag: '🇨🇴',
        hotelDestination: 'BOGOTA_COLOMBIA',
        averagePrice: 398,
        currency: 'USD'
    },
    'MDE': {
        name: 'Medellín',
        country: 'Colombia',
        flag: '🇨🇴',
        hotelDestination: 'MEDELLIN_COLOMBIA',
        averagePrice: 425,
        currency: 'USD'
    },
    
    // Mexico
    'CUN': {
        name: 'Cancún',
        country: 'México',
        flag: '🇲🇽',
        hotelDestination: 'CANCUN_MEXICO',
        averagePrice: 456,
        currency: 'USD'
    },
    'MEX': {
        name: 'Ciudad de México',
        country: 'México',
        flag: '🇲🇽',
        hotelDestination: 'MEXICO_CITY_MEXICO',
        averagePrice: 489,
        currency: 'USD'
    }
};

// ===================================
// COMMISSION TRACKING
// ===================================

/**
 * Track affiliate clicks and conversions
 */
function trackAffiliateClick(program, destination, searchParams) {
    const trackingData = {
        program: program,
        destination: destination,
        timestamp: new Date().toISOString(),
        searchParams: searchParams,
        userAgent: navigator.userAgent,
        referrer: document.referrer || 'direct',
        sessionId: generateSessionId()
    };
    
    // Send to analytics
    if (typeof gtag !== 'undefined') {
        gtag('event', 'affiliate_click', {
            event_category: 'affiliate',
            event_label: program,
            custom_parameters: {
                destination: destination,
                program: program
            }
        });
    }
    
    // Send to custom tracking endpoint (implement your own)
    // sendTrackingData(trackingData);
    
    console.log('Affiliate click tracked:', trackingData);
}

/**
 * Generate unique session ID for tracking
 */
function generateSessionId() {
    return 'sess_' + Math.random().toString(36).substring(2) + Date.now().toString(36);
}

// ===================================
// REVENUE OPTIMIZATION
// ===================================

/**
 * Smart affiliate selection based on commission rates and conversion
 */
function selectBestAffiliate(destination, searchType = 'flight') {
    const commissionRates = {
        expedia: { flight: 0.04, hotel: 0.06, conversion: 0.85 },
        hotels: { hotel: 0.08, conversion: 0.78 },
        kayak: { flight: 0.50, conversion: 0.65 }, // High commission if approved
        booking: { hotel: 0.25, conversion: 0.82 }
    };
    
    let bestOption = { program: 'expedia', expectedRevenue: 0 };
    
    Object.entries(commissionRates).forEach(([program, rates]) => {
        if (rates[searchType]) {
            const expectedRevenue = rates[searchType] * rates.conversion;
            if (expectedRevenue > bestOption.expectedRevenue) {
                bestOption = { program, expectedRevenue };
            }
        }
    });
    
    return bestOption.program;
}

// ===================================
// SETUP INSTRUCTIONS
// ===================================

/**
 * Instructions for setting up affiliate programs
 */
const SETUP_INSTRUCTIONS = {
    expedia: {
        steps: [
            '1. Sign up at https://creator.expediagroup.com/signup',
            '2. Get approved and receive your affiliate ID',
            '3. Replace YOUR_EXPEDIA_AFFILIATE_ID with actual ID',
            '4. Test affiliate links and tracking'
        ],
        commission: 'Up to 4% + performance bonuses',
        cookieDuration: '30 days'
    },
    
    kayak: {
        steps: [
            '1. Apply at https://affiliates.kayak.com/signup',
            '2. Wait for approval (1-3 business days)',
            '3. Configure affiliate ID in this file',
            '4. Implement Kayak booking functions'
        ],
        commission: 'Up to 50% of Kayak revenue',
        cookieDuration: '30 days'
    },
    
    booking: {
        steps: [
            '1. Apply via AWIN network',
            '2. Get approved for Booking.com program',
            '3. Configure affiliate tracking parameters',
            '4. Test booking flow and commission tracking'
        ],
        commission: '25-40% depending on volume',
        cookieDuration: '30 days'
    }
};

// Export configuration for use in main script
window.AFFILIATE_CONFIG = AFFILIATE_CONFIG;
window.DESTINATION_CONFIG = DESTINATION_CONFIG;
window.buildExpediaFlightUrl = buildExpediaFlightUrl;
window.buildHotelsUrl = buildHotelsUrl;
window.buildKayakFlightUrl = buildKayakFlightUrl;
window.trackAffiliateClick = trackAffiliateClick;
window.selectBestAffiliate = selectBestAffiliate;