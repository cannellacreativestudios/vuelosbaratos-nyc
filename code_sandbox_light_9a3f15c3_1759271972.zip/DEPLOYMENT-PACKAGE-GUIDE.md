# 🚀 VuelosBaratos NYC - Deployment Package Guide

## 📁 Complete File List for Netlify Deployment

### ⭐ ESSENTIAL FILES (Required)
1. **index.html** - Main website file
2. **css/style.css** - Website styling
3. **js/script.js** - Website functionality
4. **netlify.toml** - Netlify configuration
5. **netlify/functions/newsletter.js** - Email signup functionality

### 🖼️ IMAGES (All Required - Global Destinations)
1. **images/logo.svg** - Website logo
2. **images/favicon.svg** - Website icon
3. **images/hero-nyc-skyline.jpg** - Hero background
4. **images/santo-domingo.jpg** - Dominican Republic
5. **images/colombia-destination.jpg** - Colombia
6. **images/mexico-travel.jpg** - Mexico
7. **images/paris-france.jpg** - Paris, France ⭐ NEW
8. **images/london-uk.jpg** - London, UK ⭐ NEW
9. **images/tokyo-japan.jpg** - Tokyo, Japan ⭐ NEW
10. **images/dubai-uae.jpg** - Dubai, UAE ⭐ NEW
11. **images/barcelona-spain.jpg** - Barcelona, Spain ⭐ NEW
12. **images/rome-italy.jpg** - Rome, Italy ⭐ NEW

### 🔧 SEO & CONFIG FILES
1. **robots.txt** - Search engine directives
2. **sitemap.xml** - SEO sitemap
3. **favicon.ico** - Browser favicon
4. **.env.example** - Environment variables template

### 📚 OPTIONAL DOCUMENTATION
1. **README.md** - Project documentation
2. **NETLIFY-DEPLOYMENT-GUIDE.md** - Deployment instructions
3. **KLAVIYO-SETUP-GUIDE.md** - Email setup guide

## 🎯 Drag & Drop Instructions

### Method 1: Download Individual Files
1. Right-click each file in the project
2. Save to a folder called "vuelosbaratos-nyc"
3. Maintain folder structure (css/, js/, images/, netlify/)
4. Drag entire folder to Netlify

### Method 2: Bulk Download (Recommended)
1. Create folder: `vuelosbaratos-nyc`
2. Create subfolders: `css`, `js`, `images`, `netlify/functions`
3. Download all files maintaining structure
4. Drag to Netlify deployment area

## ✅ Pre-Deployment Checklist
- [ ] All 17 files downloaded
- [ ] Folder structure maintained
- [ ] index.html in root folder
- [ ] Images folder has all 9 destination photos
- [ ] netlify.toml in root folder

## 🚀 After Deployment
1. Get your live URL from Netlify
2. Add environment variables for Klaviyo
3. Test newsletter signup
4. Configure custom domain (optional)

---
**Your website is ready for IMMEDIATE deployment! 🚀**