/**
 * VuelosBaratos NYC - Newsletter Configuration
 * Email marketing and lead generation system
 */

// ===================================
// EMAIL SERVICE CONFIGURATION
// ===================================

const EMAIL_CONFIG = {
    // Customer.io Configuration (PRIMARY - Advanced behavioral automation)
    customerio: {
        siteId: 'YOUR_CUSTOMERIO_SITE_ID', // Replace with your site ID
        apiKey: 'YOUR_CUSTOMERIO_API_KEY', // Replace with your API key
        trackingApiUrl: 'https://track.customer.io/api/v1',
        appApiUrl: 'https://api.customer.io/v1/api',
        features: {
            behavioralTriggering: true,
            advancedSegmentation: true,
            priceAlertAutomation: true,
            realTimeTracking: true,
            abtesting: true
        },
        events: {
            priceAlertCreated: 'price_alert_created',
            priceDropDetected: 'price_drop_detected',
            userUpgraded: 'user_upgraded_plan',
            emailOpened: 'email_opened',
            linkClicked: 'link_clicked',
            bookingCompleted: 'booking_completed'
        },
        attributes: {
            subscription_tier: 'subscription_tier',
            preferred_destinations: 'preferred_destinations',
            price_sensitivity: 'price_sensitivity',
            booking_frequency: 'booking_frequency',
            last_booking_date: 'last_booking_date'
        }
    },
    
    // ConvertKit Configuration (Alternative)
    convertkit: {
        apiKey: 'YOUR_CONVERTKIT_API_KEY',
        formId: 'YOUR_CONVERTKIT_FORM_ID',
        baseUrl: 'https://api.convertkit.com/v3',
        tags: {
            newsletter: 'newsletter-subscriber',
            dominicana: 'interested-dominicana',
            colombia: 'interested-colombia',
            mexico: 'interested-mexico',
            vip: 'vip-subscriber'
        }
    },
    
    // Mailchimp Configuration (Alternative)
    mailchimp: {
        apiKey: 'YOUR_MAILCHIMP_API_KEY',
        listId: 'YOUR_MAILCHIMP_LIST_ID',
        serverPrefix: 'us1',
        baseUrl: 'https://us1.api.mailchimp.com/3.0'
    }
};

// ===================================
// NEWSLETTER SUBSCRIPTION TIERS
// ===================================

const SUBSCRIPTION_TIERS = {
    basic: {
        name: 'Básico',
        price: 0,
        priceText: 'GRATIS',
        features: [
            '1 ruta de vuelo',
            'Alertas semanales',
            'Descuentos hasta 30%'
        ],
        maxAlerts: 1,
        alertFrequency: 'weekly',
        emailFrequency: 'weekly'
    },
    
    premium: {
        name: 'Premium',
        price: 9.99,
        priceText: '$9.99/mes',
        features: [
            '5 rutas de vuelo',
            'Alertas diarias',
            'Descuentos hasta 70%',
            'Alertas flash instantáneas',
            'Soporte prioritario'
        ],
        maxAlerts: 5,
        alertFrequency: 'daily',
        emailFrequency: 'daily',
        hasFlashAlerts: true,
        hasPrioritySupport: true
    },
    
    vip: {
        name: 'VIP',
        price: 24.99,
        priceText: '$24.99/mes',
        features: [
            'Rutas ilimitadas',
            'Alertas en tiempo real',
            'Errores de tarifa exclusivos',
            'Análisis de tendencias',
            'Consultoría personalizada',
            'WhatsApp directo'
        ],
        maxAlerts: -1, // unlimited
        alertFrequency: 'realtime',
        emailFrequency: 'realtime',
        hasFlashAlerts: true,
        hasPrioritySupport: true,
        hasExclusiveFareErrors: true,
        hasTrendAnalysis: true,
        hasPersonalConsulting: true,
        hasWhatsAppSupport: true
    }
};

// ===================================
// EMAIL TEMPLATES
// ===================================

const EMAIL_TEMPLATES = {
    welcome: {
        subject: '¡Bienvenido a VuelosBaratos NYC! 🛫',
        content: `
            <h2>¡Hola {{firstName}}!</h2>
            <p>Gracias por suscribirte a nuestro newsletter. Ahora recibirás las mejores ofertas de vuelos desde NYC directamente en tu email.</p>
            
            <h3>¿Qué puedes esperar?</h3>
            <ul>
                <li>✈️ Ofertas exclusivas con hasta 70% de descuento</li>
                <li>🚨 Alertas de vuelos flash de 24 horas</li>
                <li>🎯 Deals personalizados para tu destino favorito</li>
                <li>💡 Tips y consejos para viajar barato</li>
            </ul>
            
            <p><strong>Tu primer regalo:</strong> Código de descuento WELCOME10 para tu próxima reserva.</p>
            
            <a href="https://vuelosbaratosnuevayork.com" style="background: #F97316; color: white; padding: 12px 24px; text-decoration: none; border-radius: 8px;">Ver Ofertas Actuales</a>
        `
    },
    
    weeklyDeals: {
        subject: '🔥 Ofertas de la semana desde NYC - Hasta 70% OFF',
        content: `
            <h2>Las mejores ofertas de esta semana</h2>
            <p>Hola {{firstName}}, estas son las ofertas más destacadas:</p>
            
            {{#deals}}
            <div style="border: 1px solid #e5e7eb; border-radius: 8px; padding: 16px; margin: 16px 0;">
                <h3>{{flag}} {{destination}}</h3>
                <p><strong>Desde ${{price}}</strong> <span style="text-decoration: line-through; color: #6b7280;">${{originalPrice}}</span></p>
                <p>{{description}}</p>
                <a href="{{bookingUrl}}" style="background: #1E3A8A; color: white; padding: 8px 16px; text-decoration: none; border-radius: 4px;">Ver Oferta</a>
            </div>
            {{/deals}}
        `
    },
    
    flashSale: {
        subject: '⚡ FLASH SALE: {{destination}} desde ${{price}} - Solo 24 horas',
        content: `
            <div style="background: #DC2626; color: white; padding: 16px; text-align: center; border-radius: 8px;">
                <h2>🚨 OFERTA FLASH - Solo 24 horas</h2>
                <h3>{{flag}} {{destination}} desde ${{price}}</h3>
                <p>Precio regular: <span style="text-decoration: line-through;">${{originalPrice}}</span></p>
                <p><strong>Ahorro: {{discount}}%</strong></p>
            </div>
            
            <p>Hola {{firstName}},</p>
            <p>Esta oferta increíble está disponible solo por 24 horas. ¡No te la pierdas!</p>
            
            <ul>
                <li>✈️ Vuelo ida y vuelta incluido</li>
                <li>🎒 Equipaje de mano incluido</li>
                <li>📅 Fechas flexibles</li>
                <li>💯 Cancelación gratuita 24h</li>
            </ul>
            
            <div style="text-align: center; margin: 24px 0;">
                <a href="{{bookingUrl}}" style="background: #F97316; color: white; padding: 16px 32px; text-decoration: none; border-radius: 8px; font-size: 18px; font-weight: bold;">RESERVAR AHORA</a>
            </div>
            
            <p style="color: #DC2626; font-weight: bold;">⏰ Oferta válida hasta: {{expirationTime}}</p>
        `
    },
    
    priceAlert: {
        subject: '💰 Alerta de precio: {{destination}} bajó a ${{newPrice}}',
        content: `
            <h2>¡El precio que esperabas! 💰</h2>
            <p>Hola {{firstName}},</p>
            <p>El vuelo que tenías en tu lista de seguimiento ha bajado de precio:</p>
            
            <div style="background: #F3F4F6; padding: 20px; border-radius: 8px; margin: 16px 0;">
                <h3>{{route}}</h3>
                <p><strong>Precio anterior:</strong> <span style="text-decoration: line-through;">${{oldPrice}}</span></p>
                <p><strong>Precio actual:</strong> <span style="color: #10B981; font-size: 24px; font-weight: bold;">${{newPrice}}</span></p>
                <p><strong>Ahorro:</strong> ${{savings}} ({{discount}}%)</p>
            </div>
            
            <p>¿Listo para reservar? Esta oferta puede cambiar en cualquier momento.</p>
            
            <a href="{{bookingUrl}}" style="background: #10B981; color: white; padding: 12px 24px; text-decoration: none; border-radius: 8px;">Reservar Ahora</a>
        `
    }
};

// ===================================
// NEWSLETTER FUNCTIONS
// ===================================

/**
 * Subscribe user to newsletter using Customer.io
 */
async function subscribeToNewsletter(subscriberData) {
    try {
        // Customer.io uses identify + track approach
        const customerId = generateCustomerId(subscriberData.email);
        
        // Step 1: Identify the customer
        await identifyCustomer(customerId, subscriberData);
        
        // Step 2: Track subscription event
        await trackCustomerEvent(customerId, EMAIL_CONFIG.customerio.events.priceAlertCreated, {
            destination_interest: subscriberData.destination,
            signup_source: 'vuelosbaratosnyc.com',
            subscription_tier: 'basic',
            preferred_language: 'es'
        });
        
        return { success: true, customerId: customerId };
        
    } catch (error) {
        console.error('Customer.io subscription error:', error);
        return { success: false, error: error.message };
    }
}

/**
 * Identify customer in Customer.io
 */
async function identifyCustomer(customerId, subscriberData) {
    const response = await fetch(`${EMAIL_CONFIG.customerio.trackingApiUrl}/customers/${customerId}`, {
        method: 'PUT',
        headers: {
            'Authorization': `Bearer ${EMAIL_CONFIG.customerio.apiKey}`,
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            email: subscriberData.email,
            first_name: subscriberData.name,
            created_at: Math.floor(Date.now() / 1000),
            [EMAIL_CONFIG.customerio.attributes.subscription_tier]: subscriberData.subscription_tier || 'basic',
            [EMAIL_CONFIG.customerio.attributes.preferred_destinations]: subscriberData.destination,
            [EMAIL_CONFIG.customerio.attributes.price_sensitivity]: subscriberData.target_price,
            signup_date: new Date().toISOString(),
            language: 'es',
            location: 'NYC',
            source: 'website_signup'
        })
    });
    
    if (!response.ok) {
        throw new Error(`Customer identification failed: ${response.status}`);
    }
}

/**
 * Track customer event in Customer.io
 */
async function trackCustomerEvent(customerId, eventName, eventData = {}) {
    const response = await fetch(`${EMAIL_CONFIG.customerio.trackingApiUrl}/customers/${customerId}/events`, {
        method: 'POST',
        headers: {
            'Authorization': `Bearer ${EMAIL_CONFIG.customerio.apiKey}`,
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            name: eventName,
            data: {
                timestamp: Math.floor(Date.now() / 1000),
                ...eventData
            }
        })
    });
    
    if (!response.ok) {
        throw new Error(`Event tracking failed: ${response.status}`);
    }
}

/**
 * Create price alert with Customer.io behavioral automation
 */
async function createPriceAlertWithCustomerIO(alertData) {
    const customerId = generateCustomerId(alertData.email);
    
    // Identify customer if not exists
    await identifyCustomer(customerId, {
        email: alertData.email,
        name: alertData.name || 'Viajero',
        subscription_tier: alertData.subscription_tier || 'basic'
    });
    
    // Track price alert creation
    await trackCustomerEvent(customerId, EMAIL_CONFIG.customerio.events.priceAlertCreated, {
        route: `${alertData.origin}-${alertData.destination}`,
        target_price: alertData.target_price,
        origin_airport: alertData.origin,
        destination_airport: alertData.destination,
        alert_type: 'price_drop',
        currency: 'USD'
    });
    
    // Store alert locally for demo (in production, store in your backend)
    const alertId = Date.now().toString();
    const alerts = JSON.parse(localStorage.getItem('priceAlerts') || '[]');
    alerts.push({
        id: alertId,
        customerId: customerId,
        ...alertData,
        status: 'active',
        createdAt: new Date().toISOString()
    });
    localStorage.setItem('priceAlerts', JSON.stringify(alerts));
    
    return { success: true, alertId: alertId, customerId: customerId };
}

/**
 * Simulate price drop detection and trigger Customer.io automation
 */
async function triggerPriceDropAlert(alertId, priceDropData) {
    const alerts = JSON.parse(localStorage.getItem('priceAlerts') || '[]');
    const alert = alerts.find(a => a.id === alertId);
    
    if (!alert) {
        throw new Error('Alert not found');
    }
    
    // Track price drop event - this will trigger Customer.io automation
    await trackCustomerEvent(alert.customerId, EMAIL_CONFIG.customerio.events.priceDropDetected, {
        alert_id: alertId,
        route: `${alert.origin}-${alert.destination}`,
        old_price: priceDropData.oldPrice,
        new_price: priceDropData.newPrice,
        savings_amount: priceDropData.oldPrice - priceDropData.newPrice,
        savings_percentage: Math.round(((priceDropData.oldPrice - priceDropData.newPrice) / priceDropData.oldPrice) * 100),
        airline: priceDropData.airline,
        booking_url: priceDropData.bookingUrl,
        expires_at: priceDropData.expiresAt
    });
    
    return { success: true, notificationSent: true };
}

/**
 * Generate unique customer ID from email
 */
function generateCustomerId(email) {
    return btoa(email).replace(/[^a-zA-Z0-9]/g, '').toLowerCase();
}

/**
 * Send welcome email to new subscriber
 */
async function sendWelcomeEmail(subscriberData) {
    const template = EMAIL_TEMPLATES.welcome;
    const personalizedContent = template.content
        .replace(/{{firstName}}/g, subscriberData.name);
    
    // Use EmailJS for client-side email sending
    if (typeof emailjs !== 'undefined') {
        try {
            await emailjs.send(
                EMAIL_CONFIG.emailjs.serviceId,
                EMAIL_CONFIG.emailjs.templateId,
                {
                    to_email: subscriberData.email,
                    to_name: subscriberData.name,
                    subject: template.subject,
                    html_content: personalizedContent
                },
                EMAIL_CONFIG.emailjs.publicKey
            );
        } catch (error) {
            console.error('Welcome email failed:', error);
        }
    }
}

/**
 * Create price alert for specific route
 */
function createPriceAlert(email, route, targetPrice) {
    const alertData = {
        email: email,
        route: route,
        targetPrice: targetPrice,
        createdAt: new Date().toISOString(),
        isActive: true
    };
    
    // Store in localStorage for demo (use backend database in production)
    const alerts = JSON.parse(localStorage.getItem('priceAlerts') || '[]');
    alerts.push(alertData);
    localStorage.setItem('priceAlerts', JSON.stringify(alerts));
    
    return alertData;
}

/**
 * Send flash sale notification
 */
function sendFlashSale(dealData) {
    const template = EMAIL_TEMPLATES.flashSale;
    const expirationTime = new Date(Date.now() + 24 * 60 * 60 * 1000).toLocaleString('es-ES');
    
    const personalizedContent = template.content
        .replace(/{{destination}}/g, dealData.destination)
        .replace(/{{flag}}/g, dealData.flag)
        .replace(/{{price}}/g, dealData.price)
        .replace(/{{originalPrice}}/g, dealData.originalPrice)
        .replace(/{{discount}}/g, dealData.discount)
        .replace(/{{bookingUrl}}/g, dealData.bookingUrl)
        .replace(/{{expirationTime}}/g, expirationTime);
    
    // Send to all subscribers (implement your email service)
    console.log('Flash sale email prepared:', {
        subject: template.subject.replace(/{{destination}}/g, dealData.destination).replace(/{{price}}/g, dealData.price),
        content: personalizedContent
    });
}

// ===================================
// LEAD MAGNETS
// ===================================

const LEAD_MAGNETS = {
    travelGuide: {
        title: 'Guía Completa: Cómo Ahorrar en Vuelos desde NYC',
        description: 'Descarga gratis nuestra guía de 20 páginas con todos los secretos para encontrar vuelos baratos.',
        fileName: 'guia-vuelos-baratos-nyc.pdf',
        gatedContent: true
    },
    
    destinationGuides: {
        'DR': {
            title: 'Guía de Viaje: República Dominicana',
            description: 'Todo lo que necesitas saber para tu viaje a RD',
            fileName: 'guia-republica-dominicana.pdf'
        },
        'CO': {
            title: 'Guía de Viaje: Colombia',
            description: 'Destinos imperdibles y consejos locales',
            fileName: 'guia-colombia.pdf'
        },
        'MX': {
            title: 'Guía de Viaje: México',
            description: 'Playas, cultura y gastronomía mexicana',
            fileName: 'guia-mexico.pdf'
        }
    },
    
    checklistPacking: {
        title: 'Checklist de Equipaje Latino',
        description: 'Lista completa de qué empacar para tu viaje a Latinoamérica',
        fileName: 'checklist-equipaje.pdf'
    }
};

// ===================================
// ANALYTICS AND TRACKING
// ===================================

/**
 * Track newsletter performance metrics
 */
function trackNewsletterMetrics(eventType, data = {}) {
    const metrics = {
        timestamp: new Date().toISOString(),
        event: eventType,
        data: data,
        sessionId: generateSessionId(),
        userAgent: navigator.userAgent,
        referrer: document.referrer
    };
    
    // Send to analytics
    if (typeof gtag !== 'undefined') {
        gtag('event', eventType, {
            event_category: 'newsletter',
            ...data
        });
    }
    
    // Store locally for demo (use analytics service in production)
    const storedMetrics = JSON.parse(localStorage.getItem('newsletterMetrics') || '[]');
    storedMetrics.push(metrics);
    localStorage.setItem('newsletterMetrics', JSON.stringify(storedMetrics));
}

// ===================================
// CUSTOMER.IO CAMPAIGNS & AUTOMATIONS
// ===================================

const CUSTOMERIO_CAMPAIGNS = {
    // Welcome series for new subscribers
    welcomeSeries: {
        name: 'VuelosBaratos NYC - Welcome Series',
        trigger: 'price_alert_created',
        emails: [
            {
                delay: '5 minutes',
                subject: '¡Bienvenido a VuelosBaratos NYC! Tu alerta está activa 🛫',
                content: 'welcome_confirmation'
            },
            {
                delay: '1 day',
                subject: 'Cómo funcionan nuestras alertas de precio ✈️',
                content: 'how_it_works_guide'
            },
            {
                delay: '3 days',
                subject: '💡 Tips para encontrar los mejores vuelos',
                content: 'travel_tips_guide'
            }
        ]
    },
    
    // Price drop alerts
    priceDropAlert: {
        name: 'Price Drop Alert - Immediate',
        trigger: 'price_drop_detected',
        condition: 'new_price < target_price',
        emails: [
            {
                delay: '0 minutes',
                subject: '🚨 ¡{{route}} bajó a ${{new_price}}! - Ahorra ${{savings_amount}}',
                content: 'price_drop_alert',
                priority: 'urgent'
            }
        ]
    },
    
    // Re-engagement for inactive users
    reengagement: {
        name: 'Re-engagement Campaign',
        trigger: 'segment',
        condition: 'days_since_last_activity > 30',
        emails: [
            {
                delay: '0 minutes',
                subject: '¿Todavía buscas vuelos baratos? Nuevas ofertas te esperan 🎯',
                content: 'reengagement_offers'
            }
        ]
    },
    
    // Upgrade campaigns for free users
    upgradePrompt: {
        name: 'Upgrade to Premium',
        trigger: 'segment',
        condition: 'subscription_tier == "basic" AND alerts_created >= 1',
        emails: [
            {
                delay: '7 days',
                subject: '🚀 Desbloquea 5 alertas más con Premium - Solo $9.99',
                content: 'upgrade_to_premium'
            }
        ]
    }
};

// ===================================
// SETUP INSTRUCTIONS
// ===================================

const EMAIL_SETUP_GUIDE = {
    customerio: {
        advantages: [
            '✅ Advanced behavioral automation perfect for price alerts',
            '✅ Real-time event tracking and triggering', 
            '✅ Sophisticated customer segmentation',
            '✅ A/B testing built-in for email optimization',
            '✅ FREE ACCOUNT available through team member!',
            '✅ Powerful API for price alert automation',
            '✅ Advanced analytics and reporting',
            '✅ Multi-channel messaging (email + SMS + push)'
        ],
        steps: [
            '1. Get FREE access through your team member at Customer.io',
            '2. Create a new workspace for VuelosBaratos NYC',
            '3. Get Site ID and API Key from workspace settings',
            '4. Replace YOUR_CUSTOMERIO_SITE_ID and YOUR_CUSTOMERIO_API_KEY',
            '5. Set up customer attributes for price sensitivity and destinations',
            '6. Create behavioral campaigns for price drop alerts',
            '7. Configure welcome email automation series',
            '8. Set up segments for different subscription tiers',
            '9. Create A/B tests for subject lines and content',
            '10. Connect to Customer.io JavaScript SDK for real-time tracking'
        ],
        cost: 'FREE through team member! (normally $150+/month)',
        perfectFor: 'Price alert newsletters with behavioral automation',
        keyFeatures: [
            'Event-driven automation (perfect for price drops)',
            'Advanced customer segmentation',
            'Real-time behavioral triggers',
            'Sophisticated A/B testing',
            'Multi-channel messaging',
            'Advanced analytics and reporting',
            'API-first architecture'
        ]
    },
    
    convertkit: {
        steps: [
            '1. Sign up for ConvertKit at https://convertkit.com',
            '2. Create a new form for newsletter signups',
            '3. Get your API key from Account Settings',
            '4. Replace YOUR_CONVERTKIT_API_KEY in this file',
            '5. Replace YOUR_CONVERTKIT_FORM_ID with your form ID',
            '6. Configure welcome email automation',
            '7. Set up tags for segmentation'
        ],
        cost: '$29/month for up to 1,000 subscribers',
        features: 'Advanced automation, segmentation, landing pages'
    }
};

// ===================================
// CUSTOMER.IO INTEGRATION BENEFITS FOR VUELOSBARATOS NYC
// ===================================

const CUSTOMERIO_BENEFITS = {
    priceAlerts: {
        description: 'Perfect for real-time price drop notifications',
        features: [
            'Instant email sending when prices drop below target',
            'Behavioral segmentation based on booking patterns',
            'Automated A/B testing of alert subject lines',
            'Smart frequency capping to avoid spam',
            'Cross-channel notifications (email + SMS for VIP users)'
        ]
    },
    
    userJourney: {
        description: 'Advanced customer lifecycle management',
        features: [
            'Welcome series based on destination preferences',
            'Upgrade prompts based on usage patterns',
            'Re-engagement for inactive subscribers',
            'Win-back campaigns for churned users',
            'Referral program automation'
        ]
    },
    
    analytics: {
        description: 'Deep insights into subscriber behavior',
        features: [
            'Price sensitivity analysis per customer',
            'Destination preference tracking',
            'Email engagement scoring',
            'Revenue attribution from alerts',
            'Churn prediction and prevention'
        ]
    }
};

// Export functions and config
window.EMAIL_CONFIG = EMAIL_CONFIG;
window.SUBSCRIPTION_TIERS = SUBSCRIPTION_TIERS;
window.CUSTOMERIO_CAMPAIGNS = CUSTOMERIO_CAMPAIGNS;
window.CUSTOMERIO_BENEFITS = CUSTOMERIO_BENEFITS;
window.EMAIL_SETUP_GUIDE = EMAIL_SETUP_GUIDE;

// Core functions
window.subscribeToNewsletter = subscribeToNewsletter;
window.createPriceAlert = createPriceAlert;
window.sendFlashSale = sendFlashSale;
window.trackNewsletterMetrics = trackNewsletterMetrics;

// Customer.io specific functions
window.identifyCustomer = identifyCustomer;
window.trackCustomerEvent = trackCustomerEvent;
window.createPriceAlertWithCustomerIO = createPriceAlertWithCustomerIO;
window.triggerPriceDropAlert = triggerPriceDropAlert;
window.generateCustomerId = generateCustomerId;

// Resources
window.LEAD_MAGNETS = LEAD_MAGNETS;