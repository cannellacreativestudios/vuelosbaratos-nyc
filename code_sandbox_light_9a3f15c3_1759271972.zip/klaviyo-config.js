/**
 * Klaviyo Configuration for VuelosBaratos NYC
 * Flight Price Alerts Newsletter Integration
 */

const KLAVIYO_CONFIG = {
    // API Configuration
    api: {
        baseUrl: 'https://a.klaviyo.com/api',
        publicKey: '', // Add your public API key here (pk_...)
        privateKey: '', // Add your private API key here (starts with pk_...)
        revision: '2024-02-15' // Klaviyo API version
    },
    
    // List Configuration for Flight Alerts
    lists: {
        newsletter: '', // Main newsletter list ID
        priceAlerts: '', // Price alerts specific list ID
        premiumUsers: '', // Premium subscribers list ID
        vipUsers: '' // VIP subscribers list ID
    },
    
    // Event Tracking for Flight Alerts
    events: {
        ALERT_CREATED: 'Created Flight Alert',
        ALERT_TRIGGERED: 'Price Alert Triggered',
        NEWSLETTER_SIGNUP: 'Newsletter Signup',
        PREMIUM_UPGRADE: 'Premium Upgrade',
        VIP_UPGRADE: 'VIP Upgrade',
        EMAIL_OPENED: 'Opened Email',
        LINK_CLICKED: 'Clicked Email Link',
        FORM_ABANDONED: 'Abandoned Signup Form'
    },
    
    // Custom Properties for Segmentation
    properties: {
        // Flight Alert Properties
        origin_airport: 'Origin Airport',
        destination_airport: 'Destination Airport',
        target_price: 'Target Price',
        alert_frequency: 'Alert Frequency',
        travel_dates: 'Preferred Travel Dates',
        
        // User Segmentation
        subscription_tier: 'Subscription Tier', // free, premium, vip
        signup_source: 'Signup Source',
        preferred_language: 'Preferred Language', // es, en
        location: 'Location',
        
        // Engagement Properties
        alerts_received: 'Total Alerts Received',
        emails_opened: 'Emails Opened',
        links_clicked: 'Links Clicked',
        last_active: 'Last Active Date',
        
        // Revenue Properties
        total_bookings: 'Total Bookings',
        total_revenue: 'Total Revenue Generated',
        avg_booking_value: 'Average Booking Value'
    },
    
    // Email Templates (create these in Klaviyo)
    flows: {
        WELCOME_SERIES: 'Welcome to VuelosBaratos NYC',
        PRICE_DROP_ALERT: 'Flight Price Drop Alert',
        WEEKLY_DEALS: 'Weekly Flight Deals Roundup',
        PREMIUM_ONBOARDING: 'Premium Member Welcome',
        VIP_ONBOARDING: 'VIP Member Welcome',
        ABANDONED_SIGNUP: 'Complete Your Flight Alert Setup'
    },
    
    // Segmentation for NYC Hispanic Market
    segments: {
        NYC_RESIDENTS: 'NYC Residents',
        HISPANIC_MARKET: 'Hispanic Market',
        DOMINICAN_ROUTES: 'Dominican Republic Routes',
        COLOMBIA_ROUTES: 'Colombia Routes',
        MEXICO_ROUTES: 'Mexico Routes',
        ECUADOR_ROUTES: 'Ecuador Routes',
        BUDGET_TRAVELERS: 'Budget Travelers (Under $500)',
        PREMIUM_TRAVELERS: 'Premium Travelers ($500+)',
        FREQUENT_FLYERS: 'Frequent Flyers (3+ alerts)'
    }
};

/**
 * Initialize Klaviyo tracking
 */
function initializeKlaviyo() {
    if (!KLAVIYO_CONFIG.api.publicKey) {
        console.warn('Klaviyo public key not configured');
        return false;
    }
    
    // Load Klaviyo tracking script
    !function(e,t,n,s,u,a){
        e.klaviyo=e.klaviyo||[],e.klaviyo.push(["account",KLAVIYO_CONFIG.api.publicKey]),
        e.klaviyo.push(["track","Active on Site"]);
        var r=t.createElement("script");r.type="text/javascript",r.async=!0,
        r.src="https://static.klaviyo.com/onsite/js/klaviyo.js?company_id="+KLAVIYO_CONFIG.api.publicKey;
        var o=t.getElementsByTagName("script")[0];o.parentNode.insertBefore(r,o)
    }(window,document);
    
    return true;
}

/**
 * Track flight alert creation
 */
function trackFlightAlert(alertData) {
    if (typeof klaviyo !== 'undefined') {
        klaviyo.push(['track', KLAVIYO_CONFIG.events.ALERT_CREATED, {
            'Origin Airport': alertData.origin,
            'Destination Airport': alertData.destination,
            'Target Price': alertData.targetPrice,
            'Alert Frequency': alertData.frequency,
            'Travel Dates': alertData.travelDates || 'Flexible',
            'Signup Source': 'Website Form'
        }]);
    }
}

/**
 * Track newsletter subscription
 */
function trackNewsletterSignup(email, userData = {}) {
    if (typeof klaviyo !== 'undefined') {
        // Identify user
        klaviyo.push(['identify', {
            '$email': email,
            '$first_name': userData.firstName || '',
            'Preferred Language': 'Spanish',
            'Location': 'New York City',
            'Subscription Tier': 'Free',
            'Signup Source': 'Website'
        }]);
        
        // Track event
        klaviyo.push(['track', KLAVIYO_CONFIG.events.NEWSLETTER_SIGNUP, {
            'List': 'Main Newsletter'
        }]);
    }
}

/**
 * Subscribe user to Klaviyo list
 */
async function subscribeToKlaviyo(email, listId, properties = {}) {
    try {
        const response = await fetch(`${KLAVIYO_CONFIG.api.baseUrl}/profile-subscription-bulk-create-jobs/`, {
            method: 'POST',
            headers: {
                'Authorization': `Klaviyo-API-Key ${KLAVIYO_CONFIG.api.privateKey}`,
                'Content-Type': 'application/json',
                'revision': KLAVIYO_CONFIG.api.revision
            },
            body: JSON.stringify({
                data: {
                    type: 'profile-subscription-bulk-create-job',
                    attributes: {
                        profiles: {
                            data: [{
                                type: 'profile',
                                attributes: {
                                    email: email,
                                    properties: properties
                                }
                            }]
                        }
                    },
                    relationships: {
                        list: {
                            data: {
                                type: 'list',
                                id: listId
                            }
                        }
                    }
                }
            })
        });
        
        if (response.ok) {
            return { success: true, provider: 'klaviyo' };
        } else {
            throw new Error(`Klaviyo API error: ${response.status}`);
        }
    } catch (error) {
        console.error('Klaviyo subscription error:', error);
        return { success: false, error: error.message };
    }
}

// Export configuration
if (typeof module !== 'undefined' && module.exports) {
    module.exports = KLAVIYO_CONFIG;
}