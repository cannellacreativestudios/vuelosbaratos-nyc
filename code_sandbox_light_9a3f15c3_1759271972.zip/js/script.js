/**
 * FlightAlerts Pro - Advanced Flight Price Alert System
 * Optimized for SEO, AEO, and conversion
 */

// ===================================
// GLOBAL VARIABLES & CONFIGURATION
// ===================================
const CONFIG = {
    // API Endpoints (replace with your actual endpoints)
    API_BASE_URL: 'https://api.flightalertspro.com',
    ENDPOINTS: {
        CREATE_ALERT: '/alerts/create',
        NEWSLETTER_SIGNUP: '/newsletter/subscribe',
        AIRPORT_SEARCH: '/airports/search',
        PRICE_HISTORY: '/prices/history',
        ANALYTICS: '/analytics/track'
    },
    
    // Feature flags
    FEATURES: {
        REAL_TIME_TRACKING: true,
        PRICE_PREDICTIONS: true,
        MOBILE_PUSH: false,
        ADVANCED_ANALYTICS: true
    },
    
    // Form configuration
    FORM: {
        STEPS: 2,
        AUTO_SAVE: true,
        VALIDATION_DELAY: 500
    },
    
    // Animation settings
    ANIMATIONS: {
        DURATION: 300,
        EASING: 'cubic-bezier(0.4, 0, 0.2, 1)',
        REDUCED_MOTION: window.matchMedia('(prefers-reduced-motion: reduce)').matches
    }
};

// Global state management
const STATE = {
    currentFormStep: 1,
    formData: {},
    isSubmitting: false,
    airportCache: new Map(),
    userSession: {
        id: generateSessionId(),
        startTime: Date.now(),
        events: []
    }
};

// ===================================
// UTILITY FUNCTIONS
// ===================================

/**
 * Generate unique session ID for analytics
 */
function generateSessionId() {
    return 'session_' + Math.random().toString(36).substr(2, 9) + '_' + Date.now();
}

/**
 * Debounce function for performance optimization
 */
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

/**
 * Throttle function for scroll events
 */
function throttle(func, limit) {
    let inThrottle;
    return function() {
        const args = arguments;
        const context = this;
        if (!inThrottle) {
            func.apply(context, args);
            inThrottle = true;
            setTimeout(() => inThrottle = false, limit);
        }
    };
}

/**
 * Analytics tracking function
 */
function trackEvent(eventName, properties = {}) {
    // Track to Google Analytics
    if (typeof gtag !== 'undefined') {
        gtag('event', eventName, {
            event_category: 'user_engagement',
            event_label: properties.label || '',
            value: properties.value || 1,
            ...properties
        });
    }
    
    // Track to internal analytics
    const event = {
        name: eventName,
        properties: {
            ...properties,
            timestamp: Date.now(),
            session_id: STATE.userSession.id,
            page_url: window.location.href,
            referrer: document.referrer,
            user_agent: navigator.userAgent
        }
    };
    
    STATE.userSession.events.push(event);
    
    // Send to analytics API (if configured)
    if (CONFIG.FEATURES.ADVANCED_ANALYTICS) {
        sendAnalyticsEvent(event);
    }
}

/**
 * Send analytics event to server
 */
async function sendAnalyticsEvent(event) {
    try {
        await fetch(CONFIG.API_BASE_URL + CONFIG.ENDPOINTS.ANALYTICS, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(event)
        });
    } catch (error) {
        console.warn('Analytics tracking failed:', error);
    }
}

/**
 * Show notification to user
 */
function showNotification(message, type = 'info', duration = 5000) {
    // Remove existing notifications
    const existingNotifications = document.querySelectorAll('.notification');
    existingNotifications.forEach(notification => notification.remove());
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <i class="fas fa-${getNotificationIcon(type)}" aria-hidden="true"></i>
            <span>${message}</span>
            <button class="notification-close" onclick="this.parentElement.parentElement.remove()" aria-label="Close notification">
                <i class="fas fa-times" aria-hidden="true"></i>
            </button>
        </div>
    `;
    
    // Add to DOM
    document.body.appendChild(notification);
    
    // Add CSS if not already present
    if (!document.querySelector('#notification-styles')) {
        const styles = document.createElement('style');
        styles.id = 'notification-styles';
        styles.textContent = `
            .notification {
                position: fixed;
                top: 100px;
                right: 20px;
                max-width: 400px;
                padding: 1rem;
                border-radius: 0.75rem;
                box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
                z-index: 1060;
                transform: translateX(100%);
                transition: transform 0.3s ease;
            }
            .notification.notification-success {
                background: #10b981;
                color: white;
            }
            .notification.notification-error {
                background: #ef4444;
                color: white;
            }
            .notification.notification-info {
                background: #3b82f6;
                color: white;
            }
            .notification.notification-warning {
                background: #f59e0b;
                color: white;
            }
            .notification-content {
                display: flex;
                align-items: center;
                gap: 0.75rem;
            }
            .notification-close {
                background: none;
                border: none;
                color: inherit;
                cursor: pointer;
                padding: 0.25rem;
                margin-left: auto;
            }
        `;
        document.head.appendChild(styles);
    }
    
    // Animate in
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Auto remove
    if (duration > 0) {
        setTimeout(() => {
            notification.style.transform = 'translateX(100%)';
            setTimeout(() => notification.remove(), 300);
        }, duration);
    }
    
    // Track notification
    trackEvent('notification_shown', {
        message_type: type,
        message: message
    });
}

/**
 * Get notification icon based on type
 */
function getNotificationIcon(type) {
    const icons = {
        success: 'check-circle',
        error: 'exclamation-circle',
        warning: 'exclamation-triangle',
        info: 'info-circle'
    };
    return icons[type] || 'info-circle';
}

/**
 * Validate email address
 */
function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// ===================================
// NAVIGATION FUNCTIONALITY
// ===================================

/**
 * Initialize navigation
 */
function initializeNavigation() {
    const navToggle = document.getElementById('nav-toggle');
    const navMenu = document.getElementById('nav-menu');
    const header = document.getElementById('header');
    
    // Mobile menu toggle
    if (navToggle && navMenu) {
        navToggle.addEventListener('click', () => {
            const isExpanded = navToggle.getAttribute('aria-expanded') === 'true';
            
            navToggle.setAttribute('aria-expanded', !isExpanded);
            navToggle.classList.toggle('active');
            navMenu.classList.toggle('active');
            
            trackEvent('mobile_menu_toggle', { action: isExpanded ? 'close' : 'open' });
        });
    }
    
    // Close mobile menu when clicking on links
    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
        link.addEventListener('click', () => {
            navToggle.classList.remove('active');
            navMenu.classList.remove('active');
            navToggle.setAttribute('aria-expanded', 'false');
        });
    });
    
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            
            if (target) {
                const headerHeight = header.offsetHeight;
                const targetPosition = target.offsetTop - headerHeight - 20;
                
                window.scrollTo({
                    top: targetPosition,
                    behavior: 'smooth'
                });
                
                trackEvent('anchor_link_click', {
                    target: this.getAttribute('href')
                });
            }
        });
    });
}

// ===================================
// FLIGHT ALERT FORM FUNCTIONALITY
// ===================================

/**
 * Initialize flight alert form
 */
function initializeFlightAlertForm() {
    const form = document.getElementById('hero-alert-form');
    if (!form) return;
    
    // Initialize form steps
    updateFormStep(1);
    
    // Initialize airport autocomplete
    initializeAirportAutocomplete();
    
    // Initialize form validation
    initializeFormValidation();
    
    // Initialize form submission
    form.addEventListener('submit', handleFlightAlertSubmission);
    
    // Initialize swap airports functionality
    const swapButton = document.querySelector('.swap-airports');
    if (swapButton) {
        swapButton.addEventListener('click', swapAirports);
    }
    
    // Auto-save form data
    if (CONFIG.FORM.AUTO_SAVE) {
        const formInputs = form.querySelectorAll('input, select');
        formInputs.forEach(input => {
            input.addEventListener('input', debounce(autoSaveFormData, 1000));
        });
    }
    
    // Load saved form data
    loadSavedFormData();
}

/**
 * Update form step display and progress
 */
function updateFormStep(stepNumber) {
    const steps = document.querySelectorAll('.form-step');
    const progressFill = document.querySelector('.progress-fill');
    const progressText = document.querySelector('.progress-text');
    
    // Update active step
    steps.forEach((step, index) => {
        step.classList.toggle('active', index + 1 === stepNumber);
    });
    
    // Update progress bar
    const progress = (stepNumber / CONFIG.FORM.STEPS) * 100;
    if (progressFill) {
        progressFill.style.width = `${progress}%`;
    }
    
    if (progressText) {
        progressText.textContent = `Step ${stepNumber} of ${CONFIG.FORM.STEPS}`;
    }
    
    STATE.currentFormStep = stepNumber;
    
    // Track step completion
    trackEvent('form_step_viewed', {
        step_number: stepNumber,
        step_name: getStepName(stepNumber)
    });
}

/**
 * Get step name for analytics
 */
function getStepName(stepNumber) {
    const stepNames = {
        1: 'flight_details',
        2: 'notification_preferences'
    };
    return stepNames[stepNumber] || `step_${stepNumber}`;
}

/**
 * Navigate to next form step
 */
function nextFormStep() {
    if (validateCurrentStep()) {
        if (STATE.currentFormStep < CONFIG.FORM.STEPS) {
            updateFormStep(STATE.currentFormStep + 1);
            
            trackEvent('form_step_completed', {
                step_number: STATE.currentFormStep - 1,
                step_name: getStepName(STATE.currentFormStep - 1)
            });
        }
    }
}

/**
 * Navigate to previous form step
 */
function prevFormStep() {
    if (STATE.currentFormStep > 1) {
        updateFormStep(STATE.currentFormStep - 1);
    }
}

/**
 * Validate current form step
 */
function validateCurrentStep() {
    const currentStep = document.querySelector('.form-step.active');
    if (!currentStep) return false;
    
    const requiredFields = currentStep.querySelectorAll('[required]');
    let isValid = true;
    
    requiredFields.forEach(field => {
        if (!validateField(field)) {
            isValid = false;
        }
    });
    
    return isValid;
}

/**
 * Validate individual form field
 */
function validateField(field) {
    const value = field.value.trim();
    const fieldName = field.name;
    let isValid = true;
    let errorMessage = '';
    
    // Remove existing error styling
    field.classList.remove('error');
    removeFieldError(field);
    
    // Required field validation
    if (field.hasAttribute('required') && !value) {
        isValid = false;
        errorMessage = 'This field is required';
    }
    
    // Email validation
    if (fieldName === 'email' && value && !validateEmail(value)) {
        isValid = false;
        errorMessage = 'Please enter a valid email address';
    }
    
    // Airport validation (basic)
    if ((fieldName === 'from_airport' || fieldName === 'to_airport') && value && value.length < 2) {
        isValid = false;
        errorMessage = 'Please enter at least 2 characters';
    }
    
    // Price validation
    if (fieldName === 'target_price' && value) {
        const price = parseFloat(value);
        if (isNaN(price) || price < 50 || price > 10000) {
            isValid = false;
            errorMessage = 'Please enter a price between $50 and $10,000';
        }
    }
    
    // Show error if invalid
    if (!isValid) {
        field.classList.add('error');
        showFieldError(field, errorMessage);
        
        trackEvent('form_field_error', {
            field_name: fieldName,
            error_message: errorMessage
        });
    }
    
    return isValid;
}

/**
 * Show field error message
 */
function showFieldError(field, message) {
    const errorElement = document.createElement('div');
    errorElement.className = 'field-error';
    errorElement.textContent = message;
    errorElement.setAttribute('role', 'alert');
    
    field.parentNode.appendChild(errorElement);
    
    // Add error styles if not present
    if (!document.querySelector('#field-error-styles')) {
        const styles = document.createElement('style');
        styles.id = 'field-error-styles';
        styles.textContent = `
            .field-error {
                color: #ef4444;
                font-size: 0.875rem;
                margin-top: 0.25rem;
                font-weight: 500;
            }
            .form-group input.error,
            .form-group select.error {
                border-color: #ef4444;
                box-shadow: 0 0 0 3px rgba(239, 68, 68, 0.1);
            }
        `;
        document.head.appendChild(styles);
    }
}

/**
 * Remove field error message
 */
function removeFieldError(field) {
    const errorElement = field.parentNode.querySelector('.field-error');
    if (errorElement) {
        errorElement.remove();
    }
}

/**
 * Initialize form validation listeners
 */
function initializeFormValidation() {
    const form = document.getElementById('hero-alert-form');
    if (!form) return;
    
    const inputs = form.querySelectorAll('input, select');
    
    inputs.forEach(input => {
        // Validate on blur with debounce
        input.addEventListener('blur', () => {
            setTimeout(() => validateField(input), CONFIG.FORM.VALIDATION_DELAY);
        });
        
        // Clear errors on input
        input.addEventListener('input', () => {
            if (input.classList.contains('error')) {
                input.classList.remove('error');
                removeFieldError(input);
            }
        });
    });
}

/**
 * Initialize airport autocomplete functionality
 */
function initializeAirportAutocomplete() {
    const fromInput = document.getElementById('from-airport');
    const toInput = document.getElementById('to-airport');
    
    if (fromInput) {
        initializeAirportInput(fromInput);
    }
    
    if (toInput) {
        initializeAirportInput(toInput);
    }
}

/**
 * Initialize individual airport input with autocomplete
 */
function initializeAirportInput(input) {
    const debouncedSearch = debounce(searchAirports, 300);
    
    input.addEventListener('input', (e) => {
        const query = e.target.value.trim();
        if (query.length >= 2) {
            debouncedSearch(query, input);
        } else {
            hideAirportSuggestions(input);
        }
    });
    
    // Hide suggestions when clicking outside
    document.addEventListener('click', (e) => {
        if (!input.contains(e.target)) {
            hideAirportSuggestions(input);
        }
    });
}

/**
 * Search airports with caching
 */
async function searchAirports(query, inputElement) {
    // Check cache first
    if (STATE.airportCache.has(query)) {
        showAirportSuggestions(STATE.airportCache.get(query), inputElement);
        return;
    }
    
    try {
        // Simulate API call with mock data for now
        const mockAirports = getMockAirports(query);
        
        // Cache results
        STATE.airportCache.set(query, mockAirports);
        
        showAirportSuggestions(mockAirports, inputElement);
        
    } catch (error) {
        console.warn('Airport search failed:', error);
        showNotification('Unable to search airports. Please try again.', 'error');
    }
}

/**
 * Get mock airport data (replace with real API call)
 */
function getMockAirports(query) {
    const airports = [
        { code: 'JFK', name: 'John F. Kennedy International Airport', city: 'New York', country: 'United States' },
        { code: 'LAX', name: 'Los Angeles International Airport', city: 'Los Angeles', country: 'United States' },
        { code: 'LHR', name: 'London Heathrow Airport', city: 'London', country: 'United Kingdom' },
        { code: 'CDG', name: 'Charles de Gaulle Airport', city: 'Paris', country: 'France' },
        { code: 'NRT', name: 'Narita International Airport', city: 'Tokyo', country: 'Japan' },
        { code: 'SYD', name: 'Sydney Airport', city: 'Sydney', country: 'Australia' },
        { code: 'DXB', name: 'Dubai International Airport', city: 'Dubai', country: 'United Arab Emirates' },
        { code: 'SIN', name: 'Singapore Changi Airport', city: 'Singapore', country: 'Singapore' },
        { code: 'FRA', name: 'Frankfurt Airport', city: 'Frankfurt', country: 'Germany' },
        { code: 'AMS', name: 'Amsterdam Airport Schiphol', city: 'Amsterdam', country: 'Netherlands' }
    ];
    
    return airports.filter(airport => 
        airport.code.toLowerCase().includes(query.toLowerCase()) ||
        airport.name.toLowerCase().includes(query.toLowerCase()) ||
        airport.city.toLowerCase().includes(query.toLowerCase())
    ).slice(0, 5);
}

/**
 * Show airport suggestions dropdown
 */
function showAirportSuggestions(airports, inputElement) {
    hideAirportSuggestions(inputElement); // Remove existing suggestions
    
    if (airports.length === 0) return;
    
    const suggestionsContainer = document.createElement('div');
    suggestionsContainer.className = 'airport-suggestions';
    suggestionsContainer.setAttribute('role', 'listbox');
    
    airports.forEach((airport, index) => {
        const suggestionItem = document.createElement('div');
        suggestionItem.className = 'airport-suggestion-item';
        suggestionItem.setAttribute('role', 'option');
        suggestionItem.setAttribute('tabindex', '-1');
        suggestionItem.innerHTML = `
            <div class="airport-code">${airport.code}</div>
            <div class="airport-details">
                <div class="airport-name">${airport.name}</div>
                <div class="airport-location">${airport.city}, ${airport.country}</div>
            </div>
        `;
        
        suggestionItem.addEventListener('click', () => {
            inputElement.value = `${airport.city} (${airport.code})`;
            hideAirportSuggestions(inputElement);
            
            trackEvent('airport_selected', {
                airport_code: airport.code,
                airport_name: airport.name,
                selection_method: 'click'
            });
        });
        
        suggestionsContainer.appendChild(suggestionItem);
    });
    
    // Position and show suggestions
    const inputContainer = inputElement.closest('.airport-input');
    inputContainer.style.position = 'relative';
    inputContainer.appendChild(suggestionsContainer);
    
    // Add CSS if not present
    if (!document.querySelector('#airport-suggestions-styles')) {
        const styles = document.createElement('style');
        styles.id = 'airport-suggestions-styles';
        styles.textContent = `
            .airport-suggestions {
                position: absolute;
                top: 100%;
                left: 0;
                right: 0;
                background: white;
                border: 1px solid #e5e7eb;
                border-radius: 0.5rem;
                box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
                z-index: 1000;
                max-height: 200px;
                overflow-y: auto;
            }
            .airport-suggestion-item {
                display: flex;
                align-items: center;
                gap: 1rem;
                padding: 0.75rem;
                cursor: pointer;
                transition: background-color 0.15s;
            }
            .airport-suggestion-item:hover {
                background: #f3f4f6;
            }
            .airport-code {
                font-weight: 700;
                color: #2563eb;
                font-size: 0.875rem;
                min-width: 40px;
            }
            .airport-details {
                flex: 1;
            }
            .airport-name {
                font-weight: 500;
                font-size: 0.875rem;
                color: #111827;
            }
            .airport-location {
                font-size: 0.75rem;
                color: #6b7280;
            }
        `;
        document.head.appendChild(styles);
    }
}

/**
 * Hide airport suggestions dropdown
 */
function hideAirportSuggestions(inputElement) {
    const inputContainer = inputElement.closest('.airport-input');
    const suggestions = inputContainer.querySelector('.airport-suggestions');
    if (suggestions) {
        suggestions.remove();
    }
}

/**
 * Swap airports functionality
 */
function swapAirports() {
    const fromInput = document.getElementById('from-airport');
    const toInput = document.getElementById('to-airport');
    
    if (fromInput && toInput) {
        const tempValue = fromInput.value;
        fromInput.value = toInput.value;
        toInput.value = tempValue;
        
        trackEvent('airports_swapped');
    }
}

/**
 * Auto-save form data to localStorage
 */
function autoSaveFormData() {
    const form = document.getElementById('hero-alert-form');
    if (!form) return;
    
    const formData = new FormData(form);
    const data = Object.fromEntries(formData.entries());
    
    localStorage.setItem('flightAlertFormData', JSON.stringify(data));
    STATE.formData = data;
}

/**
 * Load saved form data from localStorage
 */
function loadSavedFormData() {
    try {
        const savedData = localStorage.getItem('flightAlertFormData');
        if (savedData) {
            const data = JSON.parse(savedData);
            STATE.formData = data;
            
            // Populate form fields
            Object.entries(data).forEach(([key, value]) => {
                const field = document.querySelector(`[name="${key}"]`);
                if (field) {
                    field.value = value;
                }
            });
        }
    } catch (error) {
        console.warn('Failed to load saved form data:', error);
    }
}

/**
 * Handle flight alert form submission
 */
async function handleFlightAlertSubmission(e) {
    e.preventDefault();
    
    if (STATE.isSubmitting) return;
    
    // Final validation
    if (!validateCurrentStep()) {
        showNotification('Please fix the errors before submitting', 'error');
        return;
    }
    
    STATE.isSubmitting = true;
    
    // Show loading state
    const submitButton = e.target.querySelector('.form-submit-btn');
    const originalText = submitButton.innerHTML;
    submitButton.innerHTML = '<i class="fas fa-spinner fa-spin" aria-hidden="true"></i> Creating Alert...';
    submitButton.disabled = true;
    
    try {
        // Collect form data
        const formData = new FormData(e.target);
        const alertData = {
            from_airport: formData.get('from_airport'),
            to_airport: formData.get('to_airport'),
            travel_dates: formData.get('travel_dates'),
            target_price: formData.get('target_price'),
            email: formData.get('email'),
            frequency: formData.get('frequency'),
            created_at: new Date().toISOString(),
            session_id: STATE.userSession.id
        };
        
        // Track form submission attempt
        trackEvent('flight_alert_form_submitted', {
            has_target_price: !!alertData.target_price,
            frequency: alertData.frequency,
            travel_dates_type: alertData.travel_dates
        });
        
        // Submit to API (simulate for now)
        await submitFlightAlert(alertData);
        
        // Show success message
        showNotification('🎉 Flight alert created successfully! Check your email for confirmation.', 'success', 7000);
        
        // Clear form and storage
        e.target.reset();
        localStorage.removeItem('flightAlertFormData');
        updateFormStep(1);
        
        // Track successful submission
        trackEvent('flight_alert_created', {
            route: `${alertData.from_airport} → ${alertData.to_airport}`,
            success: true
        });
        
    } catch (error) {
        console.error('Flight alert submission failed:', error);
        showNotification('Something went wrong. Please try again.', 'error');
        
        trackEvent('flight_alert_error', {
            error_message: error.message
        });
        
    } finally {
        // Reset button state
        submitButton.innerHTML = originalText;
        submitButton.disabled = false;
        STATE.isSubmitting = false;
    }
}

/**
 * Submit flight alert to API
 */
async function submitFlightAlert(alertData) {
    // Simulate API call - replace with actual API endpoint
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            // Simulate occasional failures for testing
            if (Math.random() > 0.9) {
                reject(new Error('API temporarily unavailable'));
            } else {
                resolve({
                    id: 'alert_' + Date.now(),
                    status: 'active',
                    ...alertData
                });
            }
        }, 2000);
    });
}

// ===================================
// CTA FUNCTIONS
// ===================================

/**
 * Scroll to signup form
 */
function scrollToSignup() {
    const signupForm = document.getElementById('signup-form');
    if (signupForm) {
        signupForm.scrollIntoView({ 
            behavior: 'smooth',
            block: 'center'
        });
        
        // Focus on first input
        setTimeout(() => {
            const firstInput = signupForm.querySelector('input');
            if (firstInput) {
                firstInput.focus();
            }
        }, 500);
        
        trackEvent('scroll_to_signup_clicked');
    }
}

/**
 * Open alert modal
 */
function openAlertModal() {
    trackEvent('alert_modal_opened');
    scrollToSignup();
}

/**
 * Open newsletter modal
 */
function openNewsletterModal() {
    trackEvent('newsletter_modal_opened');
    scrollToSignup();
}

/**
 * Open demo modal
 */
function openDemoModal() {
    trackEvent('demo_modal_opened');
    showNotification('Demo video coming soon!', 'info');
}

// ===================================
// INITIALIZATION
// ===================================

/**
 * Initialize all functionality when DOM is loaded
 */
document.addEventListener('DOMContentLoaded', () => {
    // Initialize core functionality
    initializeNavigation();
    initializeFlightAlertForm();
    
    // Track page view
    trackEvent('page_view', {
        page_title: document.title,
        page_url: window.location.href,
        referrer: document.referrer,
        viewport_width: window.innerWidth,
        viewport_height: window.innerHeight
    });
    
    console.log('✅ FlightAlerts Pro initialized successfully');
});

// ===================================
// EXPORT FUNCTIONS FOR GLOBAL ACCESS
// ===================================

// Make key functions available globally
window.FlightAlertsPro = {
    trackEvent,
    showNotification,
    scrollToSignup,
    openAlertModal,
    openNewsletterModal,
    openDemoModal,
    nextFormStep,
    prevFormStep
};

// Assign to global functions for HTML onclick handlers
window.scrollToSignup = scrollToSignup;
window.openAlertModal = openAlertModal;
window.openNewsletterModal = openNewsletterModal;
window.openDemoModal = openDemoModal;
window.nextFormStep = nextFormStep;
window.prevFormStep = prevFormStep;

// ===================================
// NEW WEBSITE SECTIONS FUNCTIONALITY
// ===================================

/**
 * Toggle FAQ item
 */
function toggleFaq(questionElement) {
    const faqItem = questionElement.closest('.faq-item');
    const answer = faqItem.querySelector('.faq-answer');
    const isExpanded = questionElement.getAttribute('aria-expanded') === 'true';
    
    // Close all other FAQ items
    document.querySelectorAll('.faq-question').forEach(otherQuestion => {
        if (otherQuestion !== questionElement) {
            otherQuestion.setAttribute('aria-expanded', 'false');
            const otherAnswer = otherQuestion.closest('.faq-item').querySelector('.faq-answer');
            otherAnswer.classList.remove('active');
        }
    });
    
    // Toggle current FAQ item
    questionElement.setAttribute('aria-expanded', !isExpanded);
    answer.classList.toggle('active');
    
    trackEvent('faq_toggle', {
        question_text: questionElement.querySelector('span').textContent.substring(0, 50),
        action: isExpanded ? 'close' : 'open'
    });
}

/**
 * Handle newsletter signup
 */
async function handleNewsletterSignup(e) {
    e.preventDefault();
    
    const form = e.target;
    const formData = new FormData(form);
    const email = formData.get('email');
    const name = formData.get('nombre');
    const destination = formData.get('destino_favorito');
    
    // Validate email
    if (!validateEmail(email)) {
        showNotification('Por favor ingresa un email válido', 'error');
        return;
    }
    
    // Show loading state
    const submitButton = form.querySelector('button[type="submit"]');
    const originalText = submitButton.innerHTML;
    submitButton.innerHTML = '<i class="fas fa-spinner fa-spin" aria-hidden="true"></i> Suscribiendo...';
    submitButton.disabled = true;
    
    try {
        // Submit to newsletter API (using Netlify function)
        const response = await fetch('/.netlify/functions/newsletter', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                email: email,
                nombre: name,
                destino_favorito: destination,
                source: 'newsletter_section'
            })
        });
        
        if (response.ok) {
            showNotification('¡Excelente! Te has suscrito correctamente. Revisa tu email para confirmar.', 'success', 7000);
            form.reset();
            
            trackEvent('newsletter_signup_success', {
                email_domain: email.split('@')[1],
                destination_preference: destination,
                source: 'newsletter_section'
            });
        } else {
            throw new Error('Subscription failed');
        }
        
    } catch (error) {
        console.error('Newsletter signup failed:', error);
        showNotification('Algo salió mal. Por favor intenta de nuevo.', 'error');
        
        trackEvent('newsletter_signup_error', {
            error_message: error.message,
            source: 'newsletter_section'
        });
    } finally {
        submitButton.innerHTML = originalText;
        submitButton.disabled = false;
    }
}

/**
 * Handle pricing plan signup
 */
function signupPlan(planType) {
    const planNames = {
        basic: 'Plan Básico',
        premium: 'Plan Premium',
        vip: 'Plan VIP'
    };
    
    trackEvent('pricing_plan_selected', {
        plan_type: planType,
        plan_name: planNames[planType]
    });
    
    if (planType === 'basic') {
        // Scroll to newsletter signup for free plan
        scrollToNewsletterSignup();
        showNotification('¡Perfecto! Suscríbete a nuestro newsletter gratuito para comenzar.', 'info', 5000);
    } else {
        // For premium plans, show coming soon message
        showNotification(`${planNames[planType]} estará disponible pronto. Suscríbete al newsletter para ser notificado.`, 'info', 6000);
        setTimeout(() => {
            scrollToNewsletterSignup();
        }, 2000);
    }
}

/**
 * Scroll to newsletter signup section
 */
function scrollToNewsletterSignup() {
    const newsletterSection = document.querySelector('.newsletter-section');
    if (newsletterSection) {
        newsletterSection.scrollIntoView({
            behavior: 'smooth',
            block: 'center'
        });
        
        // Focus on email input after scroll
        setTimeout(() => {
            const emailInput = document.getElementById('newsletter-email');
            if (emailInput) {
                emailInput.focus();
            }
        }, 800);
        
        trackEvent('scroll_to_newsletter_signup');
    }
}

/**
 * Open WhatsApp chat
 */
function openWhatsApp() {
    const phoneNumber = '15551234567'; // Replace with actual WhatsApp business number
    const message = encodeURIComponent('¡Hola! Me interesa saber más sobre VuelosBaratos NYC y sus alertas de precios de vuelos.');
    const whatsappURL = `https://wa.me/${phoneNumber}?text=${message}`;
    
    window.open(whatsappURL, '_blank', 'noopener,noreferrer');
    
    trackEvent('whatsapp_contact_clicked', {
        source: 'float_button'
    });
}

/**
 * Initialize new sections
 */
function initializeNewSections() {
    // Initialize newsletter form
    const newsletterForm = document.getElementById('newsletter-signup');
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', handleNewsletterSignup);
    }
    
    // Initialize FAQ accessibility
    const faqQuestions = document.querySelectorAll('.faq-question');
    faqQuestions.forEach(question => {
        question.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                toggleFaq(question);
            }
        });
    });
    
    // Initialize WhatsApp float button keyboard support
    const whatsappFloat = document.querySelector('.whatsapp-float');
    if (whatsappFloat) {
        whatsappFloat.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                openWhatsApp();
            }
        });
    }
    
    // Initialize smooth scroll for footer links
    const footerLinks = document.querySelectorAll('.footer-column a[href^="#"]');
    footerLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            const target = document.querySelector(link.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
                
                trackEvent('footer_link_click', {
                    target: link.getAttribute('href'),
                    text: link.textContent
                });
            }
        });
    });
}

// Update the main initialization to include new sections
document.addEventListener('DOMContentLoaded', () => {
    // Initialize core functionality
    initializeNavigation();
    initializeFlightAlertForm();
    initializeNewSections(); // Add this line
    
    // Track page view
    trackEvent('page_view', {
        page_title: document.title,
        page_url: window.location.href,
        referrer: document.referrer,
        viewport_width: window.innerWidth,
        viewport_height: window.innerHeight
    });
    
    console.log('✅ FlightAlerts Pro initialized successfully');
});

// Make new functions available globally
window.toggleFaq = toggleFaq;
window.signupPlan = signupPlan;
window.openWhatsApp = openWhatsApp;
window.scrollToNewsletterSignup = scrollToNewsletterSignup;