/**
 * Netlify Serverless Function - Newsletter Signup
 * FlightAlerts Pro - SEO & AEO Optimized Flight Alerts Newsletter
 */

const headers = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Content-Type': 'application/json'
};

// Email validation regex
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// Rate limiting (simple in-memory store - use Redis in production)
const rateLimitMap = new Map();
const RATE_LIMIT = 5; // requests per minute
const RATE_WINDOW = 60 * 1000; // 1 minute

function isRateLimited(ip) {
  const now = Date.now();
  const userRequests = rateLimitMap.get(ip) || [];
  
  // Clean old requests
  const recentRequests = userRequests.filter(timestamp => now - timestamp < RATE_WINDOW);
  
  if (recentRequests.length >= RATE_LIMIT) {
    return true;
  }
  
  // Add current request
  recentRequests.push(now);
  rateLimitMap.set(ip, recentRequests);
  
  return false;
}

async function subscribeToKlaviyo(email, firstName, alertData) {
  const KLAVIYO_API_KEY = process.env.KLAVIYO_API_KEY;
  const KLAVIYO_LIST_ID = process.env.KLAVIYO_LIST_ID;
  
  if (!KLAVIYO_API_KEY || !KLAVIYO_LIST_ID) {
    console.log('Klaviyo credentials not configured');
    return { success: true, provider: 'local' }; // Fallback for demo
  }
  
  try {
    // Subscribe to list and add properties
    const response = await fetch('https://a.klaviyo.com/api/profile-subscription-bulk-create-jobs/', {
      method: 'POST',
      headers: {
        'Authorization': `Klaviyo-API-Key ${KLAVIYO_API_KEY}`,
        'Content-Type': 'application/json',
        'revision': '2024-02-15'
      },
      body: JSON.stringify({
        data: {
          type: 'profile-subscription-bulk-create-job',
          attributes: {
            profiles: {
              data: [{
                type: 'profile',
                attributes: {
                  email: email,
                  first_name: firstName,
                  properties: {
                    'Origin Airport': alertData.origin,
                    'Destination Airport': alertData.destination,
                    'Target Price': alertData.targetPrice,
                    'Alert Frequency': alertData.frequency || 'instant',
                    'Preferred Language': 'Spanish',
                    'Location': 'New York City',
                    'Subscription Tier': 'Free',
                    'Signup Source': 'Website Form',
                    'Signup Date': new Date().toISOString()
                  }
                }
              }]
            }
          },
          relationships: {
            list: {
              data: {
                type: 'list',
                id: KLAVIYO_LIST_ID
              }
            }
          }
        }
      })
    });
    
    if (response.ok) {
      return { success: true, provider: 'klaviyo' };
    } else {
      const errorData = await response.json();
      throw new Error(errorData.errors?.[0]?.detail || 'Klaviyo subscription failed');
    }
  } catch (error) {
    console.error('Klaviyo error:', error);
    return { success: false, error: error.message };
  }
}

async function subscribeToConvertKit(email, firstName, alertData) {
  const CONVERTKIT_API_KEY = process.env.CONVERTKIT_API_KEY;
  const CONVERTKIT_FORM_ID = process.env.CONVERTKIT_FORM_ID;
  
  if (!CONVERTKIT_API_KEY || !CONVERTKIT_FORM_ID) {
    console.log('ConvertKit credentials not configured');
    return { success: true, provider: 'local' }; // Fallback for demo
  }
  
  try {
    const response = await fetch(`https://api.convertkit.com/v3/forms/${CONVERTKIT_FORM_ID}/subscribe`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        api_key: CONVERTKIT_API_KEY,
        email: email,
        first_name: firstName,
        tags: ['flight-alerts', 'newsletter'],
        fields: {
          origin_city: alertData.origin,
          destination_city: alertData.destination,
          target_price: alertData.targetPrice,
          alert_frequency: alertData.frequency || 'instant'
        }
      })
    });
    
    const result = await response.json();
    
    if (response.ok) {
      return { success: true, provider: 'convertkit', id: result.subscription.id };
    } else {
      throw new Error(result.message || 'ConvertKit subscription failed');
    }
  } catch (error) {
    console.error('ConvertKit error:', error);
    return { success: false, error: error.message };
  }
}

async function subscribeToCustomerIO(email, firstName, alertData) {
  const CUSTOMERIO_SITE_ID = process.env.CUSTOMERIO_SITE_ID;
  const CUSTOMERIO_API_KEY = process.env.CUSTOMERIO_API_KEY;
  
  if (!CUSTOMERIO_SITE_ID || !CUSTOMERIO_API_KEY) {
    console.log('Customer.io credentials not configured');
    return { success: true, provider: 'local' }; // Fallback for demo
  }
  
  try {
    const customerId = Buffer.from(email).toString('base64').substr(0, 16);
    
    // Create/update customer
    const customerResponse = await fetch(`https://track.customer.io/api/v1/customers/${customerId}`, {
      method: 'PUT',
      headers: {
        'Authorization': `Basic ${Buffer.from(`${CUSTOMERIO_SITE_ID}:${CUSTOMERIO_API_KEY}`).toString('base64')}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        email: email,
        first_name: firstName,
        created_at: Math.floor(Date.now() / 1000),
        flight_alert_origin: alertData.origin,
        flight_alert_destination: alertData.destination,
        flight_alert_target_price: alertData.targetPrice,
        alert_frequency: alertData.frequency || 'instant',
        subscription_source: 'website_signup',
        subscription_tier: 'free'
      })
    });
    
    if (!customerResponse.ok) {
      throw new Error('Customer.io customer creation failed');
    }
    
    // Trigger welcome event
    await fetch(`https://track.customer.io/api/v1/customers/${customerId}/events`, {
      method: 'POST',
      headers: {
        'Authorization': `Basic ${Buffer.from(`${CUSTOMERIO_SITE_ID}:${CUSTOMERIO_API_KEY}`).toString('base64')}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        name: 'flight_alert_signup',
        data: alertData
      })
    });
    
    return { success: true, provider: 'customerio', id: customerId };
    
  } catch (error) {
    console.error('Customer.io error:', error);
    return { success: false, error: error.message };
  }
}

exports.handler = async (event, context) => {
  // Handle CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ message: 'CORS preflight' })
    };
  }
  
  // Only allow POST requests
  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ 
        success: false, 
        error: 'Method not allowed. Use POST.' 
      })
    };
  }
  
  try {
    // Rate limiting
    const clientIP = event.headers['x-forwarded-for'] || event.headers['x-real-ip'] || 'unknown';
    
    if (isRateLimited(clientIP)) {
      return {
        statusCode: 429,
        headers,
        body: JSON.stringify({ 
          success: false, 
          error: 'Too many requests. Please try again later.' 
        })
      };
    }
    
    // Parse request body
    let requestBody;
    try {
      requestBody = JSON.parse(event.body);
    } catch (parseError) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ 
          success: false, 
          error: 'Invalid JSON in request body' 
        })
      };
    }
    
    const { 
      email, 
      firstName = '', 
      origin, 
      destination, 
      targetPrice, 
      frequency = 'instant' 
    } = requestBody;
    
    // Validate required fields
    if (!email) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ 
          success: false, 
          error: 'Email address is required' 
        })
      };
    }
    
    if (!emailRegex.test(email)) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ 
          success: false, 
          error: 'Invalid email address format' 
        })
      };
    }
    
    if (!origin || !destination || !targetPrice) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ 
          success: false, 
          error: 'Flight alert details (origin, destination, target price) are required' 
        })
      };
    }
    
    // Validate target price
    const price = parseFloat(targetPrice);
    if (isNaN(price) || price <= 0 || price > 50000) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ 
          success: false, 
          error: 'Invalid target price. Must be between $1 and $50,000' 
        })
      };
    }
    
    const alertData = {
      origin: origin.trim(),
      destination: destination.trim(),
      targetPrice: price,
      frequency: frequency.toLowerCase(),
      signupDate: new Date().toISOString(),
      source: 'website'
    };
    
    // Try Klaviyo first (preferred), fallback to Customer.io, then ConvertKit
    let subscriptionResult = await subscribeToKlaviyo(email, firstName, alertData);
    
    if (!subscriptionResult.success) {
      console.log('Klaviyo failed, trying Customer.io...');
      subscriptionResult = await subscribeToCustomerIO(email, firstName, alertData);
      
      if (!subscriptionResult.success) {
        console.log('Customer.io failed, trying ConvertKit...');
        subscriptionResult = await subscribeToConvertKit(email, firstName, alertData);
      }
    }
    
    if (!subscriptionResult.success) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ 
          success: false, 
          error: 'Failed to subscribe to newsletter. Please try again.' 
        })
      };
    }
    
    // Log successful signup (replace with your analytics)
    console.log(`New flight alert signup: ${email} | ${origin} → ${destination} | $${price}`);
    
    // Return success response
    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ 
        success: true,
        message: 'Successfully subscribed to flight price alerts!',
        provider: subscriptionResult.provider,
        alertData: {
          route: `${origin} → ${destination}`,
          targetPrice: `$${price}`,
          frequency: frequency
        }
      })
    };
    
  } catch (error) {
    console.error('Newsletter signup error:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ 
        success: false, 
        error: 'Internal server error. Please try again later.' 
      })
    };
  }
};