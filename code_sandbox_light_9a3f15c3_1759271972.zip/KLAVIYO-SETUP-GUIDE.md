# 🎯 Klaviyo Setup Guide for VuelosBaratos NYC
**Complete setup for flight price alerts newsletter targeting NYC Hispanic market**

---

## 🚀 **Quick Setup (5 Minutes)**

### **Step 1: Create Klaviyo Account**
1. **Go to [klaviyo.com](https://klaviyo.com)**
2. **Sign up** (FREE for up to 250 contacts)
3. **Company Information:**
   - **Company Name:** VuelosBaratos NYC
   - **Industry:** Travel & Hospitality
   - **Website:** Your future domain
   - **Country:** United States
   - **Primary Language:** Spanish

### **Step 2: Get API Credentials**
1. **Settings** → **API Keys**
2. **Create Private API Key**
   - **Name:** "Website Integration"
   - **Permissions:** Full Access (for now)
3. **Copy both keys:**
   - **Public Key** (starts with `pk_`)
   - **Private Key** (longer key for API calls)

### **Step 3: Create Your Newsletter List**
1. **Lists & Segments** → **Create List**
2. **List Name:** "VuelosBaratos NYC Newsletter"
3. **Description:** "Flight price alerts for NYC Hispanic community"
4. **Copy List ID** (you'll need this)

---

## ⚙️ **Environment Variables Setup**

Add these to your deployment platform:

```bash
# Klaviyo Configuration
KLAVIYO_API_KEY=your_private_api_key_here
KLAVIYO_LIST_ID=your_newsletter_list_id_here

# Optional Analytics
GA_MEASUREMENT_ID=G-XXXXXXXXXX
FACEBOOK_PIXEL_ID=123456789012345
```

---

## 📊 **Advanced Klaviyo Configuration**

### **Create Customer Properties (Recommended)**

In **Settings** → **Properties**, create these custom properties:

#### **Flight Alert Properties:**
- `Origin Airport` (Text) - Departure airport/city
- `Destination Airport` (Text) - Arrival airport/city  
- `Target Price` (Number) - Maximum price user wants to pay
- `Alert Frequency` (Text) - instant, daily, weekly
- `Travel Dates` (Text) - Preferred travel timeframe

#### **Segmentation Properties:**
- `Subscription Tier` (Text) - free, premium, vip
- `Preferred Language` (Text) - Spanish, English
- `Location` (Text) - NYC borough or area
- `Signup Source` (Text) - website, social, referral

#### **Engagement Properties:**
- `Alerts Received` (Number) - Total alerts sent
- `Emails Opened` (Number) - Email engagement count
- `Last Active` (Date) - Last website activity
- `Total Bookings` (Number) - Revenue tracking

### **Create Market Segments**

Go to **Lists & Segments** → **Create Segment**:

#### **1. NYC Hispanic Market**
```
Location contains "New York" AND Preferred Language equals "Spanish"
```

#### **2. Dominican Republic Routes**
```
Destination Airport contains "Santo Domingo" OR "Santiago" OR "Punta Cana"
```

#### **3. Colombia Routes**
```
Destination Airport contains "Bogotá" OR "Medellín" OR "Cartagena"
```

#### **4. Budget Travelers**
```
Target Price is less than $500
```

#### **5. Premium Prospects**
```
Target Price is greater than $500 AND Emails Opened is greater than 3
```

---

## 📧 **Essential Email Flows**

### **Flow 1: Welcome Series (REQUIRED)**
**Trigger:** Someone subscribes to newsletter

**Email Sequence:**
1. **Welcome Email** (Immediate)
   - Subject: "¡Bienvenido a VuelosBaratos NYC! 🛫"
   - Content: Thank you, confirm alert setup, what to expect

2. **Setup Confirmation** (2 hours later)
   - Subject: "Tu alerta de vuelos está activa ✅"
   - Content: Confirm flight route, show example deals

3. **First Deal Showcase** (24 hours later)
   - Subject: "¡Mira estos precios increíbles! ✈️"
   - Content: Current deals to their destination, social proof

### **Flow 2: Price Drop Alert (CRITICAL)**
**Trigger:** Custom event "Price Alert Triggered"

**Email:**
- **Subject:** "🔥 ¡Precio bajo! NYC → [Destination] desde $[Price]"
- **Content:** 
  - Price drop notification
  - Booking deadline/urgency
  - Direct booking links (affiliate)
  - Alternative dates if available

### **Flow 3: Weekly Deals Digest**
**Trigger:** Weekly (Sundays 9 AM EST)
**Audience:** Active subscribers

**Email:**
- **Subject:** "🗽 Las mejores ofertas de vuelos desde NYC esta semana"
- **Content:**
  - Top 5 deals from NYC
  - Focus on Hispanic destinations
  - Community deals and testimonials

### **Flow 4: Abandoned Signup Recovery**
**Trigger:** Started signup form but didn't complete
**Timing:** 30 minutes after abandonment

**Email:**
- **Subject:** "¿Olvidaste configurar tu alerta? ⏰"
- **Content:** 
  - Gentle reminder about incomplete setup
  - Benefits of completing signup
  - One-click completion link

---

## 🎨 **Email Templates (Spanish)**

### **Welcome Email Template:**
```
Subject: ¡Bienvenido a VuelosBaratos NYC! 🛫

Hola {{ first_name|default:"Viajero" }},

¡Bienvenido a la comunidad de viajeros inteligentes de Nueva York! 

✅ Tu alerta está configurada:
📍 Desde: {{ properties.Origin_Airport }}
🎯 Hacia: {{ properties.Destination_Airport }}  
💰 Precio objetivo: ${{ properties.Target_Price }}

¿Qué puedes esperar?
🔔 Alertas instantáneas cuando los precios bajen
💸 Ahorros promedio de $500 por vuelo
🌎 Ofertas exclusivas a destinos latinos

¡Tu próximo vuelo barato está en camino!

Saludos,
El equipo de VuelosBaratos NYC
```

### **Price Drop Alert Template:**
```
Subject: 🔥 ¡PRECIO BAJO! NYC → {{ properties.Destination_Airport }} desde ${{ properties.Current_Price }}

¡ALERTA DE PRECIO!

El vuelo que estás siguiendo acaba de bajar:

✈️ {{ properties.Origin_Airport }} → {{ properties.Destination_Airport }}
💰 Nuevo precio: ${{ properties.Current_Price }}
📉 Ahorro: ${{ properties.Savings_Amount }} ({{ properties.Savings_Percent }}%)
⏰ Oferta válida hasta: {{ properties.Deal_Expires }}

👆 RESERVA AHORA (precio sujeto a cambios)

¿No puedes viajar en estas fechas?
Ver fechas alternativas →

¡Feliz viaje!
VuelosBaratos NYC
```

---

## 📈 **Success Tracking & Analytics**

### **Key Metrics to Monitor:**

#### **Growth Metrics:**
- **Subscriber Growth Rate** - Weekly new signups
- **List Health** - Open/click rates, unsubscribe rate
- **Segmentation Performance** - Which routes/prices perform best

#### **Engagement Metrics:**
- **Email Open Rate** - Target: 25%+ (travel industry average)
- **Click-Through Rate** - Target: 3%+ 
- **Alert-to-Booking Rate** - Revenue attribution

#### **Revenue Metrics:**
- **Revenue per Email** - Affiliate commission per send
- **Customer Lifetime Value** - Total revenue per subscriber
- **Conversion to Premium** - Free to paid upgrade rate

### **A/B Testing Opportunities:**
1. **Subject Lines:** Spanish vs English, emoji usage
2. **Send Times:** Morning vs evening for NYC Hispanic market  
3. **Content Format:** Text-heavy vs visual deals
4. **CTA Buttons:** "Reservar Ahora" vs "Ver Oferta"
5. **Price Presentation:** Savings amount vs percentage

---

## 🚀 **Launch Checklist**

### **✅ Pre-Launch (Complete These First):**
- [ ] Klaviyo account created and verified
- [ ] API keys generated and saved securely
- [ ] Main newsletter list created
- [ ] Custom properties configured
- [ ] Welcome flow created and activated
- [ ] Price drop alert template ready

### **✅ Day 1 (After Deployment):**
- [ ] Test signup form with real email
- [ ] Verify welcome email received and looks good
- [ ] Check subscriber appears in Klaviyo with correct properties
- [ ] Test unsubscribe link works
- [ ] Mobile email formatting looks good

### **✅ Week 1 (Optimization):**
- [ ] Create market segments (NYC Hispanic, routes)
- [ ] Set up weekly deals flow
- [ ] Configure abandoned signup recovery
- [ ] Add Facebook/Google pixel integration
- [ ] Launch first marketing campaigns

---

## 🎯 **Growth Strategy with Klaviyo**

### **Month 1: Foundation (0-250 subscribers - FREE!)**
- **Goal:** Validate market demand and email performance
- **Focus:** Organic growth, word of mouth, social media
- **Klaviyo Features:** Basic automation, simple segmentation

### **Month 2-3: Scale (250-1,000 subscribers - $20/month)**
- **Goal:** Systematic growth and engagement optimization
- **Focus:** Content marketing, community partnerships
- **Klaviyo Features:** Advanced segmentation, A/B testing

### **Month 4-6: Revenue (1,000+ subscribers - $35+/month)**
- **Goal:** Premium subscriptions and affiliate revenue
- **Focus:** Premium features, corporate partnerships
- **Klaviyo Features:** Advanced flows, behavioral targeting

---

## 📞 **Support & Resources**

### **Klaviyo Support:**
- **Help Center:** [help.klaviyo.com](https://help.klaviyo.com)
- **Live Chat:** Available in account dashboard
- **Community:** [community.klaviyo.com](https://community.klaviyo.com)

### **Best Practices:**
- **Send Frequency:** Start with 1-2 emails/week, increase based on engagement
- **Spanish Content:** Use native Spanish, not translated text
- **Mobile First:** 70%+ of Hispanic users check email on mobile
- **Cultural Relevance:** Include Hispanic holidays, cultural references

---

## 🎉 **You're Ready to Launch!**

With Klaviyo configured, your VuelosBaratos NYC newsletter will have:

✅ **Professional email automation** for flight price alerts  
✅ **Advanced segmentation** for NYC Hispanic market  
✅ **Revenue tracking** for affiliate and subscription income  
✅ **Free tier** to validate market demand (250 contacts)  
✅ **Scalable infrastructure** for growth to 10,000+ subscribers  

**Next Step:** Add your Klaviyo credentials to your deployment and go live! 🚀

---

*Need help with setup? All configuration examples are included in this guide.*